
import { 
  User, 
  Project, 
  Task, 
  Department, 
  ProjectStatus, 
  ProjectType, 
  ProjectPriority,
  TaskStatus,
  UserRole 
} from '@prisma/client';

// NextAuth types extension
declare module "next-auth" {
  interface User {
    id: string;
    role: UserRole;
    department: string | null;
  }
  
  interface Session {
    user: {
      id: string;
      name?: string | null;
      email?: string | null;
      image?: string | null;
      role: UserRole;
      department: string | null;
    };
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    role: UserRole;
    department: string | null;
  }
}

export type ExtendedUser = User & {
  _count?: {
    assignedProjects: number;
    assignedTasks: number;
    timesheets: number;
  };
};

export type ExtendedProject = Project & {
  createdBy: User;
  updatedBy?: User;
  assignments: Array<{
    user: User;
    role: string;
  }>;
  tasks: Array<{
    task: Task;
    status: TaskStatus;
    progress: number;
  }>;
  _count?: {
    tasks: number;
    assignments: number;
    timesheets: number;
  };
};

export type ExtendedTask = Task & {
  department: Department;
  _count?: {
    projectTasks: number;
  };
};

export type DashboardStats = {
  totalProjects: number;
  activeProjects: number;
  completedProjects: number;
  totalRevenue: number;
  monthlyRevenue: number;
  totalTasks: number;
  completedTasks: number;
  totalUsers: number;
  activeUsers: number;
};

export type FinancialCalculation = {
  subtotal: number;
  margin: number;
  marginPercent: number;
  vat: number;
  total: number;
  profit: number;
};

// Navigation types
export type NavItem = {
  title: string;
  href: string;
  icon: any;
  badge?: string;
  children?: NavItem[];
};

// Form types
export type ProjectFormData = {
  name: string;
  description?: string;
  clientName: string;
  clientEmail?: string;
  clientPhone?: string;
  clientAddress?: string;
  projectType: ProjectType;
  priority: ProjectPriority;
  quotedValue: number;
  marginPercent: number;
  startDate?: Date;
  endDate?: Date;
};

export type TaskFormData = {
  name: string;
  description?: string;
  departmentId: string;
  category?: string;
  estimatedHours: number;
  isActive: boolean;
};

// Chart data types
export type ChartData = {
  name: string;
  value: number;
  color?: string;
};

export type TimeSeriesData = {
  date: string;
  value: number;
  label?: string;
};

// Workflow steps
export const WORKFLOW_STEPS = [
  'Initial Enquiry & LOI',
  'Quotation & Proposal', 
  'Deposit Invoice & Payment',
  'Purchase Order (PO) Receipt',
  'Project Kick-Off & Planning',
  'Materials Procurement',
  'RAMS Preparation',
  'Site Survey',
  'Drawings & Design Approval',
  'Fabrication',
  'Powder Coating',
  'Packing & Delivery',
  'Site Mobilisation',
  'Frame Installation',
  'Glazing & Cappings',
  'Snagging & Quality Assurance',
  'O&M Manuals & Documentation',
  'Practical Completion & Handover',
  'Invoicing & Final Payment',
  'Retention Release'
];

export type { ProjectStatus, ProjectType, ProjectPriority, TaskStatus, UserRole, Department };
