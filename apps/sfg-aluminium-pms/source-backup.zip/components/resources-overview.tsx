
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  Wrench, 
  Package, 
  Clock, 
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  Calendar,
  UserCheck,
  Settings
} from 'lucide-react';

const staffData = [
  { id: 1, name: 'John Smith', department: 'Factory', role: 'Senior Fabricator', utilization: 92, skills: ['Welding', 'CNC', 'Assembly'] },
  { id: 2, name: 'Sarah Johnson', department: 'Installation', role: 'Site Manager', utilization: 88, skills: ['Site Management', 'Quality Control', 'Safety'] },
  { id: 3, name: 'Mike Brown', department: 'Office', role: 'Project Manager', utilization: 78, skills: ['Planning', 'Coordination', 'Client Relations'] },
  { id: 4, name: 'Lisa Wilson', department: 'Factory', role: 'Powder Coater', utilization: 95, skills: ['Powder Coating', 'Quality Control', 'Maintenance'] }
];

const equipmentData = [
  { id: 1, name: 'CNC Machine #1', type: 'Manufacturing', status: 'active', utilization: 87, nextMaintenance: '2024-01-28' },
  { id: 2, name: 'Powder Coating Line', type: 'Finishing', status: 'active', utilization: 92, nextMaintenance: '2024-01-30' },
  { id: 3, name: 'Hydraulic Press #2', type: 'Forming', status: 'maintenance', utilization: 0, nextMaintenance: '2024-01-24' },
  { id: 4, name: 'Welding Station #3', type: 'Assembly', status: 'active', utilization: 76, nextMaintenance: '2024-02-02' }
];

const materialData = [
  { name: 'Aluminum Profiles', stock: 2400, unit: 'meters', reorderLevel: 500, status: 'good' },
  { name: 'Glass Units', stock: 45, unit: 'units', reorderLevel: 20, status: 'low' },
  { name: 'Powder Coating - White', stock: 85, unit: 'kg', reorderLevel: 25, status: 'good' },
  { name: 'Welding Rods', stock: 12, unit: 'boxes', reorderLevel: 15, status: 'critical' }
];

export function ResourcesOverview() {
  const [activeTab, setActiveTab] = useState<'staff' | 'equipment' | 'materials'>('staff');

  const getUtilizationColor = (utilization: number) => {
    if (utilization >= 90) return 'text-red-600';
    if (utilization >= 75) return 'text-yellow-600';
    return 'text-green-600';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'maintenance': return 'bg-yellow-100 text-yellow-800';
      case 'inactive': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStockStatusColor = (status: string) => {
    switch (status) {
      case 'good': return 'bg-green-100 text-green-800';
      case 'low': return 'bg-yellow-100 text-yellow-800';
      case 'critical': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Resource Management</h1>
        <p className="text-gray-600 mt-2">Manage staff allocation, equipment scheduling, and material planning</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Staff</p>
                <p className="text-2xl font-bold text-blue-600">23</p>
              </div>
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Equipment Active</p>
                <p className="text-2xl font-bold text-green-600">18/21</p>
              </div>
              <Wrench className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg Utilization</p>
                <p className="text-2xl font-bold text-orange-600">86%</p>
              </div>
              <TrendingUp className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Low Stock Items</p>
                <p className="text-2xl font-bold text-red-600">3</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg w-fit">
        <Button
          variant={activeTab === 'staff' ? 'default' : 'ghost'}
          onClick={() => setActiveTab('staff')}
          className="flex items-center gap-2"
        >
          <Users className="h-4 w-4" />
          Staff
        </Button>
        <Button
          variant={activeTab === 'equipment' ? 'default' : 'ghost'}
          onClick={() => setActiveTab('equipment')}
          className="flex items-center gap-2"
        >
          <Wrench className="h-4 w-4" />
          Equipment
        </Button>
        <Button
          variant={activeTab === 'materials' ? 'default' : 'ghost'}
          onClick={() => setActiveTab('materials')}
          className="flex items-center gap-2"
        >
          <Package className="h-4 w-4" />
          Materials
        </Button>
      </div>

      {/* Content */}
      {activeTab === 'staff' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {staffData.map((staff) => (
            <Card key={staff.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{staff.name}</CardTitle>
                    <p className="text-sm text-gray-600">{staff.role}</p>
                  </div>
                  <Badge className="bg-blue-100 text-blue-800">
                    {staff.department}
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Utilization</span>
                  <span className={`font-bold ${getUtilizationColor(staff.utilization)}`}>
                    {staff.utilization}%
                  </span>
                </div>
                
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${
                      staff.utilization >= 90 ? 'bg-red-500' :
                      staff.utilization >= 75 ? 'bg-yellow-500' : 'bg-green-500'
                    }`}
                    style={{ width: `${staff.utilization}%` }}
                  />
                </div>
                
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-2">Skills:</p>
                  <div className="flex flex-wrap gap-1">
                    {staff.skills.map((skill, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    <UserCheck className="h-4 w-4 mr-1" />
                    Assign
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <Calendar className="h-4 w-4 mr-1" />
                    Schedule
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {activeTab === 'equipment' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {equipmentData.map((equipment) => (
            <Card key={equipment.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{equipment.name}</CardTitle>
                    <p className="text-sm text-gray-600">{equipment.type}</p>
                  </div>
                  <Badge className={getStatusColor(equipment.status)}>
                    {equipment.status}
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Utilization</span>
                  <span className={`font-bold ${getUtilizationColor(equipment.utilization)}`}>
                    {equipment.utilization}%
                  </span>
                </div>
                
                {equipment.status === 'active' && (
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full ${
                        equipment.utilization >= 90 ? 'bg-red-500' :
                        equipment.utilization >= 75 ? 'bg-yellow-500' : 'bg-green-500'
                      }`}
                      style={{ width: `${equipment.utilization}%` }}
                    />
                  </div>
                )}
                
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4 text-gray-400" />
                  <span className="text-gray-600">Next Maintenance:</span>
                  <span className="font-medium">{equipment.nextMaintenance}</span>
                </div>
                
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    <Settings className="h-4 w-4 mr-1" />
                    Maintain
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <Calendar className="h-4 w-4 mr-1" />
                    Schedule
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {activeTab === 'materials' && (
        <Card>
          <CardHeader>
            <CardTitle>Material Inventory</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Material
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Current Stock
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Reorder Level
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {materialData.map((material, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{material.name}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {material.stock.toLocaleString()} {material.unit}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {material.reorderLevel} {material.unit}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Badge className={getStockStatusColor(material.status)}>
                          {material.status}
                        </Badge>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">
                            <Package className="h-4 w-4 mr-1" />
                            Reorder
                          </Button>
                          {material.status === 'critical' && (
                            <Button variant="destructive" size="sm">
                              <AlertTriangle className="h-4 w-4 mr-1" />
                              Urgent
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
