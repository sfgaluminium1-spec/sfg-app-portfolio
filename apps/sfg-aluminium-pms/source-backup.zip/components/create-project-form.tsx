
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2 } from 'lucide-react';
import { ProjectType, ProjectPriority } from '@/lib/types';

interface CreateProjectFormProps {
  onSuccess: () => void;
}

export function CreateProjectForm({ onSuccess }: CreateProjectFormProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    clientName: '',
    clientEmail: '',
    clientPhone: '',
    clientAddress: '',
    projectType: 'SUPPLY_INSTALL' as ProjectType,
    priority: 'MEDIUM' as ProjectPriority,
    quotedValue: '',
    marginPercent: '45',
    startDate: '',
    endDate: '',
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const getDefaultMargin = (projectType: ProjectType) => {
    const margins = {
      SUPPLY_INSTALL: '45',
      SUPPLY_ONLY: '30',
      SERVICES: '30',
      MAINTENANCE: '10',
      REPAIR: '10',
      SIMPLE_SALE: '5',
    };
    return margins[projectType] || '45';
  };

  const handleProjectTypeChange = (value: ProjectType) => {
    setFormData(prev => ({
      ...prev,
      projectType: value,
      marginPercent: getDefaultMargin(value)
    }));
  };

  const calculateTotals = () => {
    const quotedValue = parseFloat(formData.quotedValue) || 0;
    const marginPercent = parseFloat(formData.marginPercent) || 0;
    const marginAmount = (quotedValue * marginPercent) / 100;
    const vatAmount = (quotedValue * 20) / 100;
    const totalValue = quotedValue + vatAmount;
    
    return {
      quotedValue,
      marginAmount,
      vatAmount,
      totalValue,
      profit: marginAmount
    };
  };

  const totals = calculateTotals();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await fetch('/api/projects', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          quotedValue: parseFloat(formData.quotedValue) || 0,
          marginPercent: parseFloat(formData.marginPercent) || 0,
        }),
      });

      if (response.ok) {
        onSuccess();
      } else {
        const data = await response.json();
        setError(data.error || 'Failed to create project');
      }
    } catch (error) {
      setError('An error occurred while creating the project');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Basic Information */}
      <div className="space-y-4">
        <h3 className="text-lg font-medium">Basic Information</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="name">Project Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              placeholder="Enter project name"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="priority">Priority</Label>
            <Select value={formData.priority} onValueChange={(value: ProjectPriority) => handleInputChange('priority', value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="LOW">Low</SelectItem>
                <SelectItem value="MEDIUM">Medium</SelectItem>
                <SelectItem value="HIGH">High</SelectItem>
                <SelectItem value="URGENT">Urgent</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => handleInputChange('description', e.target.value)}
            placeholder="Project description (optional)"
            rows={3}
          />
        </div>
      </div>

      {/* Client Information */}
      <div className="space-y-4">
        <h3 className="text-lg font-medium">Client Information</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="clientName">Client Name *</Label>
            <Input
              id="clientName"
              value={formData.clientName}
              onChange={(e) => handleInputChange('clientName', e.target.value)}
              placeholder="Enter client name"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="clientEmail">Client Email</Label>
            <Input
              id="clientEmail"
              type="email"
              value={formData.clientEmail}
              onChange={(e) => handleInputChange('clientEmail', e.target.value)}
              placeholder="client@example.com"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="clientPhone">Client Phone</Label>
            <Input
              id="clientPhone"
              value={formData.clientPhone}
              onChange={(e) => handleInputChange('clientPhone', e.target.value)}
              placeholder="Enter phone number"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="clientAddress">Client Address</Label>
          <Textarea
            id="clientAddress"
            value={formData.clientAddress}
            onChange={(e) => handleInputChange('clientAddress', e.target.value)}
            placeholder="Enter client address"
            rows={2}
          />
        </div>
      </div>

      {/* Project Details */}
      <div className="space-y-4">
        <h3 className="text-lg font-medium">Project Details</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="projectType">Project Type</Label>
            <Select value={formData.projectType} onValueChange={handleProjectTypeChange}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="SUPPLY_INSTALL">Supply & Install (45% margin)</SelectItem>
                <SelectItem value="SUPPLY_ONLY">Supply Only (30% margin)</SelectItem>
                <SelectItem value="SERVICES">Services (30% margin)</SelectItem>
                <SelectItem value="MAINTENANCE">Maintenance (10% margin)</SelectItem>
                <SelectItem value="REPAIR">Repair (10% margin)</SelectItem>
                <SelectItem value="SIMPLE_SALE">Simple Sale (5% margin)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="marginPercent">Margin %</Label>
            <Input
              id="marginPercent"
              type="number"
              step="0.1"
              value={formData.marginPercent}
              onChange={(e) => handleInputChange('marginPercent', e.target.value)}
              placeholder="45"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="startDate">Start Date</Label>
            <Input
              id="startDate"
              type="date"
              value={formData.startDate}
              onChange={(e) => handleInputChange('startDate', e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="endDate">End Date</Label>
            <Input
              id="endDate"
              type="date"
              value={formData.endDate}
              onChange={(e) => handleInputChange('endDate', e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Financial Information */}
      <div className="space-y-4">
        <h3 className="text-lg font-medium">Financial Information</h3>
        
        <div className="space-y-2">
          <Label htmlFor="quotedValue">Quoted Value (£) *</Label>
          <Input
            id="quotedValue"
            type="number"
            step="0.01"
            value={formData.quotedValue}
            onChange={(e) => handleInputChange('quotedValue', e.target.value)}
            placeholder="0.00"
            required
          />
        </div>

        {formData.quotedValue && (
          <div className="bg-gray-50 p-4 rounded-lg space-y-2">
            <h4 className="font-medium text-sm">Financial Summary</h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-600">Quoted Value:</span>
                <span className="float-right font-medium">£{totals.quotedValue.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-gray-600">Margin ({formData.marginPercent}%):</span>
                <span className="float-right font-medium">£{totals.marginAmount.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-gray-600">VAT (20%):</span>
                <span className="float-right font-medium">£{totals.vatAmount.toLocaleString()}</span>
              </div>
              <div className="border-t pt-2">
                <span className="text-gray-900 font-medium">Total Value:</span>
                <span className="float-right font-bold">£{totals.totalValue.toLocaleString()}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Submit */}
      <div className="flex justify-end space-x-4">
        <Button type="button" variant="outline" onClick={() => setFormData({
          name: '',
          description: '',
          clientName: '',
          clientEmail: '',
          clientPhone: '',
          clientAddress: '',
          projectType: 'SUPPLY_INSTALL' as ProjectType,
          priority: 'MEDIUM' as ProjectPriority,
          quotedValue: '',
          marginPercent: '45',
          startDate: '',
          endDate: '',
        })}>
          Reset
        </Button>
        <Button type="submit" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Creating...
            </>
          ) : (
            'Create Project'
          )}
        </Button>
      </div>
    </form>
  );
}
