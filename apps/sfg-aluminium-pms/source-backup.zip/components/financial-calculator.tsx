
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Calculator, 
  DollarSign, 
  TrendingUp, 
  Clock, 
  Users,
  AlertTriangle,
  CheckCircle,
  Info
} from 'lucide-react';
import { ProjectType } from '@/lib/types';

interface CalculationResult {
  subtotal: number;
  margin: number;
  marginPercent: number;
  vat: number;
  total: number;
  profit: number;
  costPrice: number;
  breakEvenHours: number;
  dailyOverheadCoverage: number;
}

export function FinancialCalculator() {
  const [projectType, setProjectType] = useState<ProjectType>('SUPPLY_INSTALL');
  const [quotedValue, setQuotedValue] = useState('');
  const [customMargin, setCustomMargin] = useState('');
  const [laborHours, setLaborHours] = useState('');
  const [materialCost, setMaterialCost] = useState('');
  const [isWeekend, setIsWeekend] = useState(false);
  const [customerType, setCustomerType] = useState('standard');
  
  // SFG Aluminium business rates
  const rates = {
    hourlyWage: 18.0,
    chargeOutRate: 36.0,
    overtimeRate: 27.0,
    weekendMultiplier: 1.5,
    vatRate: 20.0,
    dailyOverhead: 2500,
    monthlyOverhead: 50000,
  };

  const projectMargins = {
    SUPPLY_INSTALL: 45,
    SUPPLY_ONLY: 30,
    SERVICES: 30,
    MAINTENANCE: 10,
    REPAIR: 10,
    SIMPLE_SALE: 5,
  };

  const customerMargins = {
    standard: 0,
    corporate: 55,
    corporateAdmin: 20,
  };

  const calculateResults = (): CalculationResult => {
    const baseValue = parseFloat(quotedValue) || 0;
    const hours = parseFloat(laborHours) || 0;
    const materials = parseFloat(materialCost) || 0;
    
    // Determine margin percentage
    let marginPercent = customMargin ? parseFloat(customMargin) : projectMargins[projectType];
    
    // Apply customer-specific margins
    if (customerType === 'corporate') {
      marginPercent = Math.max(marginPercent, customerMargins.corporate);
    }
    
    // Calculate labor costs
    const hourlyRate = isWeekend ? rates.chargeOutRate * rates.weekendMultiplier : rates.chargeOutRate;
    const laborCost = hours * hourlyRate;
    
    // Calculate totals
    const subtotal = baseValue;
    const margin = (subtotal * marginPercent) / 100;
    const costPrice = subtotal - margin;
    const vat = (subtotal * rates.vatRate) / 100;
    const total = subtotal + vat;
    const profit = margin - (materials + (hours * rates.hourlyWage));
    
    // Calculate break-even and overhead coverage
    const breakEvenHours = costPrice / rates.chargeOutRate;
    const dailyOverheadCoverage = profit / rates.dailyOverhead;
    
    return {
      subtotal,
      margin,
      marginPercent,
      vat,
      total,
      profit,
      costPrice,
      breakEvenHours,
      dailyOverheadCoverage,
    };
  };

  const results = calculateResults();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-GB', { 
      style: 'currency', 
      currency: 'GBP',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const getMarginStatus = (marginPercent: number, projectType: ProjectType) => {
    const recommended = projectMargins[projectType];
    if (marginPercent >= recommended) {
      return { status: 'good', color: 'bg-green-100 text-green-800', icon: CheckCircle };
    } else if (marginPercent >= recommended * 0.8) {
      return { status: 'warning', color: 'bg-yellow-100 text-yellow-800', icon: AlertTriangle };
    } else {
      return { status: 'poor', color: 'bg-red-100 text-red-800', icon: AlertTriangle };
    }
  };

  const marginStatus = getMarginStatus(results.marginPercent, projectType);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Financial Calculator</h1>
        <p className="text-gray-600 mt-2">Calculate pricing, margins, and profitability for SFG Aluminium projects</p>
      </div>

      <Tabs defaultValue="calculator" className="space-y-6">
        <TabsList>
          <TabsTrigger value="calculator">Price Calculator</TabsTrigger>
          <TabsTrigger value="rates">Rate Calculator</TabsTrigger>
          <TabsTrigger value="overhead">Overhead Analysis</TabsTrigger>
        </TabsList>

        <TabsContent value="calculator" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Input Form */}
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calculator className="h-5 w-5" />
                    Project Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Project Type</Label>
                      <Select value={projectType} onValueChange={(value: ProjectType) => setProjectType(value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="SUPPLY_INSTALL">Supply & Install</SelectItem>
                          <SelectItem value="SUPPLY_ONLY">Supply Only</SelectItem>
                          <SelectItem value="SERVICES">Services</SelectItem>
                          <SelectItem value="MAINTENANCE">Maintenance</SelectItem>
                          <SelectItem value="REPAIR">Repair</SelectItem>
                          <SelectItem value="SIMPLE_SALE">Simple Sale</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Customer Type</Label>
                      <Select value={customerType} onValueChange={setCustomerType}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="standard">Standard</SelectItem>
                          <SelectItem value="corporate">Corporate (55% min margin)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Quoted Value (£)</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={quotedValue}
                        onChange={(e) => setQuotedValue(e.target.value)}
                        placeholder="0.00"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Custom Margin % (Optional)</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={customMargin}
                        onChange={(e) => setCustomMargin(e.target.value)}
                        placeholder={`Default: ${projectMargins[projectType]}%`}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Labor Hours</Label>
                      <Input
                        type="number"
                        step="0.5"
                        value={laborHours}
                        onChange={(e) => setLaborHours(e.target.value)}
                        placeholder="0"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Material Cost (£)</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={materialCost}
                        onChange={(e) => setMaterialCost(e.target.value)}
                        placeholder="0.00"
                      />
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="weekend"
                      checked={isWeekend}
                      onChange={(e) => setIsWeekend(e.target.checked)}
                      className="rounded"
                    />
                    <Label htmlFor="weekend">Weekend/Premium Rate (1.5x)</Label>
                  </div>
                </CardContent>
              </Card>

              {/* Business Rules */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Info className="h-5 w-5" />
                    SFG Aluminium Business Rules
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <h4 className="font-medium mb-2">Standard Rates</h4>
                      <ul className="space-y-1 text-gray-600">
                        <li>Hourly Wage: £{rates.hourlyWage}</li>
                        <li>Charge-out Rate: £{rates.chargeOutRate}</li>
                        <li>Overtime Rate: £{rates.overtimeRate}</li>
                        <li>Weekend Multiplier: {rates.weekendMultiplier}x</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2">Project Margins</h4>
                      <ul className="space-y-1 text-gray-600">
                        <li>Supply & Install: {projectMargins.SUPPLY_INSTALL}%</li>
                        <li>Supply Only: {projectMargins.SUPPLY_ONLY}%</li>
                        <li>Services: {projectMargins.SERVICES}%</li>
                        <li>Maintenance: {projectMargins.MAINTENANCE}%</li>
                        <li>Repair: {projectMargins.REPAIR}%</li>
                        <li>Simple Sale: {projectMargins.SIMPLE_SALE}%</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Results */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5" />
                    Financial Summary
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Quoted Value:</span>
                      <span className="font-medium">{formatCurrency(results.subtotal)}</span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Margin:</span>
                      <div className="text-right">
                        <div className="font-medium">{formatCurrency(results.margin)}</div>
                        <Badge className={marginStatus.color}>
                          <marginStatus.icon className="h-3 w-3 mr-1" />
                          {results.marginPercent.toFixed(1)}%
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-600">VAT (20%):</span>
                      <span className="font-medium">{formatCurrency(results.vat)}</span>
                    </div>
                    
                    <div className="border-t pt-3 flex justify-between">
                      <span className="font-medium">Total Value:</span>
                      <span className="font-bold text-lg">{formatCurrency(results.total)}</span>
                    </div>
                    
                    <div className="border-t pt-3 flex justify-between">
                      <span className="font-medium">Net Profit:</span>
                      <span className={`font-bold ${results.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatCurrency(results.profit)}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Analysis Metrics
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Cost Price:</span>
                      <span className="font-medium">{formatCurrency(results.costPrice)}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-600">Break-even Hours:</span>
                      <span className="font-medium">{results.breakEvenHours.toFixed(1)} hrs</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-600">Daily Overhead Coverage:</span>
                      <span className={`font-medium ${results.dailyOverheadCoverage >= 1 ? 'text-green-600' : 'text-red-600'}`}>
                        {(results.dailyOverheadCoverage * 100).toFixed(1)}%
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button className="w-full" size="sm">Save Calculation</Button>
                  <Button variant="outline" className="w-full" size="sm">Export Quote</Button>
                  <Button variant="outline" className="w-full" size="sm">Create Project</Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="rates" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Rate Calculator
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-4">
                  <h4 className="font-medium">Standard Working Hours</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Daily Hours:</span>
                      <span>8.5 (paid)</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Weekly Hours:</span>
                      <span>42.5</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Working Days:</span>
                      <span>Mon-Fri 8AM-5PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Breaks:</span>
                      <span>10min + 30min + 15min</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h4 className="font-medium">Rate Structure</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Hourly Wage:</span>
                      <span>£{rates.hourlyWage}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Charge-out Rate:</span>
                      <span>£{rates.chargeOutRate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Overtime Rate:</span>
                      <span>£{rates.overtimeRate} (1.5x)</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Weekend Rate:</span>
                      <span>£{(rates.chargeOutRate * rates.weekendMultiplier).toFixed(0)} (1.5x)</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h4 className="font-medium">Daily Calculations</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Daily Wage Cost:</span>
                      <span>£{(rates.hourlyWage * 8.5).toFixed(0)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Daily Charge-out:</span>
                      <span>£{(rates.chargeOutRate * 8.5).toFixed(0)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Daily Markup:</span>
                      <span>£{((rates.chargeOutRate - rates.hourlyWage) * 8.5).toFixed(0)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="overhead" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Monthly Overhead</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">
                  {formatCurrency(rates.monthlyOverhead)}
                </div>
                <p className="text-sm text-gray-600 mt-2">
                  28% of monthly turnover (£178,571)
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Daily Overhead</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-orange-600">
                  {formatCurrency(rates.dailyOverhead)}
                </div>
                <p className="text-sm text-gray-600 mt-2">
                  Based on 20 working days
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Annual Target</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">
                  £2,142,857
                </div>
                <p className="text-sm text-gray-600 mt-2">
                  Total annual overhead target
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
