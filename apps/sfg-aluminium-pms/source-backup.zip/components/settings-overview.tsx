
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  Settings, 
  DollarSign, 
  Clock, 
  Users, 
  Building2,
  Calculator,
  AlertTriangle,
  Save
} from 'lucide-react';

export function SettingsOverview() {
  const [rates, setRates] = useState({
    hourlyWage: '18.00',
    chargeOutRate: '36.00',
    overtimeRate: '27.00',
    weekendMultiplier: '1.5',
    vatRate: '20.0',
  });

  const [margins, setMargins] = useState({
    supplyInstall: '45',
    supplyOnly: '30',
    services: '30',
    maintenance: '10',
    repair: '10',
    simpleSale: '5',
    corporateMargin: '55',
    corporateAdmin: '20',
  });

  const [overhead, setOverhead] = useState({
    monthlyOverhead: '50000',
    annualOverhead: '2142857',
    dailyOverhead: '2500',
    turnoverPercentage: '28',
  });

  const [workingHours, setWorkingHours] = useState({
    dailyHours: '8.5',
    weeklyHours: '42.5',
    startTime: '08:00',
    endTime: '17:00',
    morningBreak: '10',
    lunchBreak: '30',
    afternoonBreak: '15',
  });

  const handleSave = (section: string) => {
    // In a real app, this would save to the database
    console.log(`Saving ${section} settings...`);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">System Settings</h1>
        <p className="text-gray-600 mt-2">Configure SFG Aluminium business rules, rates, and system preferences</p>
      </div>

      <Tabs defaultValue="rates" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="rates">Rates</TabsTrigger>
          <TabsTrigger value="margins">Margins</TabsTrigger>
          <TabsTrigger value="overhead">Overhead</TabsTrigger>
          <TabsTrigger value="hours">Working Hours</TabsTrigger>
          <TabsTrigger value="system">System</TabsTrigger>
        </TabsList>

        {/* Rates Settings */}
        <TabsContent value="rates" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Hourly Rates & Charges
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="hourlyWage">Hourly Wage (£)</Label>
                  <Input
                    id="hourlyWage"
                    type="number"
                    step="0.01"
                    value={rates.hourlyWage}
                    onChange={(e) => setRates(prev => ({ ...prev, hourlyWage: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="chargeOutRate">Charge-out Rate (£)</Label>
                  <Input
                    id="chargeOutRate"
                    type="number"
                    step="0.01"
                    value={rates.chargeOutRate}
                    onChange={(e) => setRates(prev => ({ ...prev, chargeOutRate: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="overtimeRate">Overtime Rate (£)</Label>
                  <Input
                    id="overtimeRate"
                    type="number"
                    step="0.01"
                    value={rates.overtimeRate}
                    onChange={(e) => setRates(prev => ({ ...prev, overtimeRate: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="weekendMultiplier">Weekend Multiplier</Label>
                  <Input
                    id="weekendMultiplier"
                    type="number"
                    step="0.1"
                    value={rates.weekendMultiplier}
                    onChange={(e) => setRates(prev => ({ ...prev, weekendMultiplier: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="vatRate">VAT Rate (%)</Label>
                  <Input
                    id="vatRate"
                    type="number"
                    step="0.1"
                    value={rates.vatRate}
                    onChange={(e) => setRates(prev => ({ ...prev, vatRate: e.target.value }))}
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <Button onClick={() => handleSave('rates')}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Rates
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Margins Settings */}
        <TabsContent value="margins" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Project Type Margins
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="supplyInstall">Supply & Install (%)</Label>
                  <Input
                    id="supplyInstall"
                    type="number"
                    step="0.1"
                    value={margins.supplyInstall}
                    onChange={(e) => setMargins(prev => ({ ...prev, supplyInstall: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="supplyOnly">Supply Only (%)</Label>
                  <Input
                    id="supplyOnly"
                    type="number"
                    step="0.1"
                    value={margins.supplyOnly}
                    onChange={(e) => setMargins(prev => ({ ...prev, supplyOnly: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="services">Services (%)</Label>
                  <Input
                    id="services"
                    type="number"
                    step="0.1"
                    value={margins.services}
                    onChange={(e) => setMargins(prev => ({ ...prev, services: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="maintenance">Maintenance (%)</Label>
                  <Input
                    id="maintenance"
                    type="number"
                    step="0.1"
                    value={margins.maintenance}
                    onChange={(e) => setMargins(prev => ({ ...prev, maintenance: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="repair">Repair (%)</Label>
                  <Input
                    id="repair"
                    type="number"
                    step="0.1"
                    value={margins.repair}
                    onChange={(e) => setMargins(prev => ({ ...prev, repair: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="simpleSale">Simple Sale (%)</Label>
                  <Input
                    id="simpleSale"
                    type="number"
                    step="0.1"
                    value={margins.simpleSale}
                    onChange={(e) => setMargins(prev => ({ ...prev, simpleSale: e.target.value }))}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5" />
                  Customer Margins
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="corporateMargin">Corporate Margin (%)</Label>
                  <Input
                    id="corporateMargin"
                    type="number"
                    step="0.1"
                    value={margins.corporateMargin}
                    onChange={(e) => setMargins(prev => ({ ...prev, corporateMargin: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="corporateAdmin">Corporate Admin (%)</Label>
                  <Input
                    id="corporateAdmin"
                    type="number"
                    step="0.1"
                    value={margins.corporateAdmin}
                    onChange={(e) => setMargins(prev => ({ ...prev, corporateAdmin: e.target.value }))}
                  />
                </div>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">Margin Guidelines</h4>
                  <div className="space-y-1 text-sm text-blue-800">
                    <div className="flex justify-between">
                      <span>Quotation Drop Rate:</span>
                      <span>40-45%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>PO Drop (Low):</span>
                      <span>≤5%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>PO Drop (High):</span>
                      <span>≥28%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex justify-end">
            <Button onClick={() => handleSave('margins')}>
              <Save className="h-4 w-4 mr-2" />
              Save Margins
            </Button>
          </div>
        </TabsContent>

        {/* Overhead Settings */}
        <TabsContent value="overhead" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                Overhead & Targets
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="monthlyOverhead">Monthly Overhead (£)</Label>
                  <Input
                    id="monthlyOverhead"
                    type="number"
                    value={overhead.monthlyOverhead}
                    onChange={(e) => setOverhead(prev => ({ ...prev, monthlyOverhead: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="annualOverhead">Annual Overhead (£)</Label>
                  <Input
                    id="annualOverhead"
                    type="number"
                    value={overhead.annualOverhead}
                    onChange={(e) => setOverhead(prev => ({ ...prev, annualOverhead: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dailyOverhead">Daily Overhead (£)</Label>
                  <Input
                    id="dailyOverhead"
                    type="number"
                    value={overhead.dailyOverhead}
                    onChange={(e) => setOverhead(prev => ({ ...prev, dailyOverhead: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="turnoverPercentage">Overhead % of Turnover</Label>
                  <Input
                    id="turnoverPercentage"
                    type="number"
                    step="0.1"
                    value={overhead.turnoverPercentage}
                    onChange={(e) => setOverhead(prev => ({ ...prev, turnoverPercentage: e.target.value }))}
                  />
                </div>
              </div>

              <div className="bg-yellow-50 p-4 rounded-lg">
                <h4 className="font-medium text-yellow-900 mb-2">Calculated Targets</h4>
                <div className="grid grid-cols-2 gap-4 text-sm text-yellow-800">
                  <div>
                    <span className="text-gray-600">Monthly Turnover Target:</span>
                    <span className="float-right font-medium">
                      £{Math.round(parseFloat(overhead.monthlyOverhead) / (parseFloat(overhead.turnoverPercentage) / 100)).toLocaleString()}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-600">Daily Turnover Target:</span>
                    <span className="float-right font-medium">
                      £{Math.round(parseFloat(overhead.dailyOverhead) / (parseFloat(overhead.turnoverPercentage) / 100)).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <Button onClick={() => handleSave('overhead')}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Overhead
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Working Hours Settings */}
        <TabsContent value="hours" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Working Hours & Breaks
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dailyHours">Daily Hours (Paid)</Label>
                  <Input
                    id="dailyHours"
                    type="number"
                    step="0.5"
                    value={workingHours.dailyHours}
                    onChange={(e) => setWorkingHours(prev => ({ ...prev, dailyHours: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="weeklyHours">Weekly Hours</Label>
                  <Input
                    id="weeklyHours"
                    type="number"
                    step="0.5"
                    value={workingHours.weeklyHours}
                    onChange={(e) => setWorkingHours(prev => ({ ...prev, weeklyHours: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="startTime">Start Time</Label>
                  <Input
                    id="startTime"
                    type="time"
                    value={workingHours.startTime}
                    onChange={(e) => setWorkingHours(prev => ({ ...prev, startTime: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="endTime">End Time</Label>
                  <Input
                    id="endTime"
                    type="time"
                    value={workingHours.endTime}
                    onChange={(e) => setWorkingHours(prev => ({ ...prev, endTime: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="morningBreak">Morning Break (minutes)</Label>
                  <Input
                    id="morningBreak"
                    type="number"
                    value={workingHours.morningBreak}
                    onChange={(e) => setWorkingHours(prev => ({ ...prev, morningBreak: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="lunchBreak">Lunch Break (minutes)</Label>
                  <Input
                    id="lunchBreak"
                    type="number"
                    value={workingHours.lunchBreak}
                    onChange={(e) => setWorkingHours(prev => ({ ...prev, lunchBreak: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="afternoonBreak">Afternoon Break (minutes)</Label>
                  <Input
                    id="afternoonBreak"
                    type="number"
                    value={workingHours.afternoonBreak}
                    onChange={(e) => setWorkingHours(prev => ({ ...prev, afternoonBreak: e.target.value }))}
                  />
                </div>
              </div>

              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-medium text-green-900 mb-2">Schedule Summary</h4>
                <div className="text-sm text-green-800">
                  <p>Standard: Monday - Friday, {workingHours.startTime} - {workingHours.endTime}</p>
                  <p>Breaks: {workingHours.morningBreak}min (10AM) + {workingHours.lunchBreak}min (lunch) + {workingHours.afternoonBreak}min (3PM)</p>
                  <p>Paid Hours: {workingHours.dailyHours}/day, {workingHours.weeklyHours}/week</p>
                </div>
              </div>

              <div className="flex justify-end">
                <Button onClick={() => handleSave('hours')}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Working Hours
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* System Settings */}
        <TabsContent value="system" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                System Configuration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border rounded-lg p-4">
                  <h4 className="font-medium mb-2">Database Status</h4>
                  <div className="flex items-center gap-2">
                    <Badge className="bg-green-100 text-green-800">Connected</Badge>
                    <span className="text-sm text-gray-600">PostgreSQL Database</span>
                  </div>
                </div>

                <div className="border rounded-lg p-4">
                  <h4 className="font-medium mb-2">System Statistics</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Total Projects:</span>
                      <span className="float-right font-medium">24</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Total Tasks:</span>
                      <span className="float-right font-medium">142</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Active Users:</span>
                      <span className="float-right font-medium">8</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Departments:</span>
                      <span className="float-right font-medium">5</span>
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg p-4">
                  <h4 className="font-medium mb-2">Version Information</h4>
                  <div className="text-sm text-gray-600">
                    <p>SFG Aluminium PMS v1.0.0</p>
                    <p>Last Updated: January 2024</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
