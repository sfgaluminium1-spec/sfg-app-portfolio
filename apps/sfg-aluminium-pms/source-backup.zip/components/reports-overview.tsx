
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  FileText, 
  Download, 
  TrendingUp, 
  DollarSign, 
  BarChart3,
  PieChart,
  Calendar,
  Users
} from 'lucide-react';

const reportTemplates = [
  {
    id: 'financial',
    name: 'Financial Performance Report',
    description: 'Revenue, margins, profitability analysis',
    icon: DollarSign,
    color: 'bg-green-100 text-green-800',
    frequency: 'Monthly'
  },
  {
    id: 'project',
    name: 'Project Status Report',
    description: 'Project progress, timelines, deliverables',
    icon: BarChart3,
    color: 'bg-blue-100 text-blue-800',
    frequency: 'Weekly'
  },
  {
    id: 'resource',
    name: 'Resource Utilization Report',
    description: 'Team utilization, capacity planning',
    icon: Users,
    color: 'bg-purple-100 text-purple-800',
    frequency: 'Weekly'
  },
  {
    id: 'task',
    name: 'Task Completion Report',
    description: 'Task progress across departments',
    icon: PieChart,
    color: 'bg-orange-100 text-orange-800',
    frequency: 'Daily'
  },
  {
    id: 'margin',
    name: 'Margin Analysis Report',
    description: 'Project margins, cost analysis',
    icon: TrendingUp,
    color: 'bg-red-100 text-red-800',
    frequency: 'Monthly'
  },
  {
    id: 'timeline',
    name: 'Timeline Performance Report',
    description: 'Schedule adherence, delays analysis',
    icon: Calendar,
    color: 'bg-indigo-100 text-indigo-800',
    frequency: 'Weekly'
  }
];

const recentReports = [
  {
    name: 'January Financial Summary',
    type: 'Financial',
    generated: '2024-01-23',
    status: 'ready'
  },
  {
    name: 'Weekly Project Status',
    type: 'Project',
    generated: '2024-01-22',
    status: 'ready'
  },
  {
    name: 'Resource Utilization - Week 3',
    type: 'Resource',
    generated: '2024-01-21',
    status: 'processing'
  }
];

export function ReportsOverview() {
  const [selectedReport, setSelectedReport] = useState<string | null>(null);

  const mockMetrics = {
    totalRevenue: 1250000,
    monthlyGrowth: 8.5,
    activeProjects: 8,
    completionRate: 87.5,
    teamUtilization: 86,
    averageMargin: 42.3
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-GB', { 
      style: 'currency', 
      currency: 'GBP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Reports & Analytics</h1>
          <p className="text-gray-600 mt-2">Generate comprehensive reports and analyze business performance</p>
        </div>
        
        <Button>
          <FileText className="h-4 w-4 mr-2" />
          Custom Report
        </Button>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <DollarSign className="h-6 w-6 text-green-600 mx-auto mb-2" />
              <div className="text-lg font-bold text-green-600">
                {formatCurrency(mockMetrics.totalRevenue)}
              </div>
              <p className="text-xs text-gray-600">Total Revenue</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <TrendingUp className="h-6 w-6 text-blue-600 mx-auto mb-2" />
              <div className="text-lg font-bold text-blue-600">
                +{mockMetrics.monthlyGrowth}%
              </div>
              <p className="text-xs text-gray-600">Monthly Growth</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <BarChart3 className="h-6 w-6 text-purple-600 mx-auto mb-2" />
              <div className="text-lg font-bold text-purple-600">
                {mockMetrics.activeProjects}
              </div>
              <p className="text-xs text-gray-600">Active Projects</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <PieChart className="h-6 w-6 text-orange-600 mx-auto mb-2" />
              <div className="text-lg font-bold text-orange-600">
                {mockMetrics.completionRate}%
              </div>
              <p className="text-xs text-gray-600">Completion Rate</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <Users className="h-6 w-6 text-indigo-600 mx-auto mb-2" />
              <div className="text-lg font-bold text-indigo-600">
                {mockMetrics.teamUtilization}%
              </div>
              <p className="text-xs text-gray-600">Team Utilization</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <TrendingUp className="h-6 w-6 text-red-600 mx-auto mb-2" />
              <div className="text-lg font-bold text-red-600">
                {mockMetrics.averageMargin}%
              </div>
              <p className="text-xs text-gray-600">Avg Margin</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Report Templates & Recent Reports */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Report Templates */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Report Templates</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {reportTemplates.map((template) => (
                  <div
                    key={template.id}
                    className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => setSelectedReport(template.id)}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${template.color}`}>
                          <template.icon className="h-5 w-5" />
                        </div>
                        <div>
                          <h4 className="font-medium text-sm">{template.name}</h4>
                          <p className="text-xs text-gray-600 mt-1">{template.description}</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary" className="text-xs">
                        {template.frequency}
                      </Badge>
                      <Button size="sm" variant="outline">
                        <Download className="h-4 w-4 mr-1" />
                        Generate
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Reports */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Recent Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentReports.map((report, index) => (
                  <div key={index} className="border rounded-lg p-3">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium text-sm">{report.name}</h4>
                      <Badge 
                        className={`text-xs ${
                          report.status === 'ready' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-yellow-100 text-yellow-800'
                        }`}
                      >
                        {report.status}
                      </Badge>
                    </div>
                    
                    <div className="text-xs text-gray-600 mb-2">
                      {report.type} • {report.generated}
                    </div>
                    
                    {report.status === 'ready' && (
                      <Button size="sm" variant="outline" className="w-full">
                        <Download className="h-4 w-4 mr-1" />
                        Download
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="mt-4">
            <CardHeader>
              <CardTitle>SFG Business Rules</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Standard Margin:</span>
                  <span className="font-medium">45%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">VAT Rate:</span>
                  <span className="font-medium">20%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Daily Overhead:</span>
                  <span className="font-medium">£2,500</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Charge-out Rate:</span>
                  <span className="font-medium">£36/hour</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
