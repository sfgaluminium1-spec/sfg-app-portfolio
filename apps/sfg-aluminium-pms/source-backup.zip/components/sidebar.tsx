
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { signOut, useSession } from 'next-auth/react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  LayoutDashboard, 
  FolderOpen, 
  CheckSquare, 
  Calculator, 
  Calendar, 
  TrendingUp, 
  Users, 
  FileText, 
  Settings, 
  LogOut,
  Building2,
  ChevronLeft,
  ChevronRight,
  Grid3x3,
  Hash,
  FileStack,
  UserCheck,
  Shield,
  GitBranch,
  BookOpen,
  Zap,
  Activity,
  ScrollText
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';

const coreNav = [
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { name: 'Projects', href: '/projects', icon: FolderOpen },
  { name: 'Tasks', href: '/tasks', icon: CheckSquare },
  { name: 'Financial Calculator', href: '/financial', icon: Calculator },
  { name: 'Scheduling', href: '/scheduling', icon: Calendar },
  { name: 'Cost Control', href: '/cost-control', icon: TrendingUp },
  { name: 'Resources', href: '/resources', icon: Users },
  { name: 'Reports', href: '/reports', icon: FileText },
];

const integrationNav = [
  { name: 'App Registry', href: '/app-registry', icon: Grid3x3 },
  { name: 'Base Numbers', href: '/base-numbers', icon: Hash },
  { name: 'Documents', href: '/documents-lifecycle', icon: FileStack },
  { name: 'Customers', href: '/customers', icon: UserCheck },
  { name: 'Staff Management', href: '/staff', icon: Shield },
  { name: 'Workflows', href: '/workflows', icon: GitBranch },
  { name: 'API Docs', href: '/api-docs', icon: BookOpen },
  { name: 'MCP Config', href: '/mcp-config', icon: Zap },
  { name: 'Integration Hub', href: '/integration-hub', icon: Activity },
  { name: 'Procedures', href: '/procedures', icon: ScrollText },
];

const settingsNav = [
  { name: 'Settings', href: '/settings', icon: Settings },
];

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);
  const pathname = usePathname();
  const { data: session } = useSession();

  const renderNavSection = (title: string, items: typeof coreNav) => (
    <div className="mb-6">
      {!collapsed && (
        <h3 className="px-3 mb-2 text-xs font-semibold text-gray-400 uppercase tracking-wider">
          {title}
        </h3>
      )}
      <div className="space-y-1">
        {items.map((item) => {
          const isActive = pathname === item.href || pathname?.startsWith(`${item.href}/`);
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center space-x-3 p-2.5 rounded-lg transition-colors",
                isActive 
                  ? "bg-blue-600 text-white" 
                  : "text-gray-300 hover:bg-gray-800 hover:text-white"
              )}
              title={collapsed ? item.name : undefined}
            >
              <item.icon className="h-5 w-5 flex-shrink-0" />
              {!collapsed && <span className="font-medium text-sm">{item.name}</span>}
            </Link>
          );
        })}
      </div>
    </div>
  );

  return (
    <div className={cn(
      "flex flex-col bg-gray-900 text-white transition-all duration-300 h-screen",
      collapsed ? "w-16" : "w-64",
      className
    )}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-700 flex-shrink-0">
        <div className="flex items-center space-x-3 min-w-0">
          <div className="p-2 bg-blue-600 rounded-lg flex-shrink-0">
            <Building2 className="h-6 w-6" />
          </div>
          {!collapsed && (
            <div className="min-w-0">
              <h1 className="font-bold text-lg truncate">SFG Aluminium</h1>
              <p className="text-xs text-gray-400 truncate">Complete System</p>
            </div>
          )}
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setCollapsed(!collapsed)}
          className="text-gray-400 hover:text-white hover:bg-gray-800 flex-shrink-0"
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>

      {/* Navigation */}
      <ScrollArea className="flex-1 px-4 py-4">
        {renderNavSection('Core', coreNav)}
        {renderNavSection('Integration', integrationNav)}
        {renderNavSection('System', settingsNav)}
      </ScrollArea>

      {/* User Section */}
      <div className="p-4 border-t border-gray-700 flex-shrink-0">
        <div className="flex items-center space-x-3 mb-3">
          <Avatar className="h-8 w-8 flex-shrink-0">
            <AvatarFallback className="bg-blue-600 text-white text-sm">
              {session?.user?.name?.slice(0, 2).toUpperCase() || 'UN'}
            </AvatarFallback>
          </Avatar>
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">
                {session?.user?.name || 'Unknown User'}
              </p>
              <p className="text-xs text-gray-400 truncate">
                {session?.user?.email || 'No Email'}
              </p>
            </div>
          )}
        </div>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={() => signOut({ callbackUrl: '/auth/signin' })}
          className={cn(
            "text-gray-400 hover:text-white hover:bg-gray-800",
            collapsed ? "w-full p-2" : "w-full justify-start"
          )}
        >
          <LogOut className="h-4 w-4" />
          {!collapsed && <span className="ml-2">Sign Out</span>}
        </Button>
      </div>
    </div>
  );
}
