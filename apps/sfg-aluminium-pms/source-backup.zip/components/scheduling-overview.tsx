
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, Users, AlertTriangle, CheckCircle, MapPin } from 'lucide-react';

const mockScheduleData = [
  {
    id: '1',
    project: 'Office Complex Phase 2',
    phase: 'Fabrication',
    team: 'Factory Team A',
    startDate: '2024-01-24',
    endDate: '2024-01-26',
    status: 'active',
    priority: 'high'
  },
  {
    id: '2', 
    project: 'Retail Park Extension',
    phase: 'Installation',
    team: 'Installation Team B',
    startDate: '2024-01-25',
    endDate: '2024-01-28',
    status: 'scheduled',
    priority: 'medium'
  },
  {
    id: '3',
    project: 'Hospital Wing Curtain Wall',
    phase: 'Powder Coating',
    team: 'Factory Team B',
    startDate: '2024-01-26',
    endDate: '2024-01-27',
    status: 'scheduled',
    priority: 'high'
  }
];

const resourceData = [
  { name: 'Factory Team A', utilization: 85, available: 2, total: 8 },
  { name: 'Factory Team B', utilization: 92, available: 1, total: 6 },
  { name: 'Installation Team A', utilization: 78, available: 3, total: 5 },
  { name: 'Installation Team B', utilization: 88, available: 1, total: 4 },
];

export function SchedulingOverview() {
  const [viewMode, setViewMode] = useState<'calendar' | 'gantt' | 'resource'>('calendar');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'delayed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Scheduling & Resource Planning</h1>
          <p className="text-gray-600 mt-2">Manage project timelines, resource allocation, and capacity planning</p>
        </div>
        
        <div className="flex gap-2">
          <Button
            variant={viewMode === 'calendar' ? 'default' : 'outline'}
            onClick={() => setViewMode('calendar')}
          >
            <Calendar className="h-4 w-4 mr-2" />
            Calendar
          </Button>
          <Button
            variant={viewMode === 'gantt' ? 'default' : 'outline'}
            onClick={() => setViewMode('gantt')}
          >
            <Clock className="h-4 w-4 mr-2" />
            Gantt
          </Button>
          <Button
            variant={viewMode === 'resource' ? 'default' : 'outline'}
            onClick={() => setViewMode('resource')}
          >
            <Users className="h-4 w-4 mr-2" />
            Resources
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Projects</p>
                <p className="text-2xl font-bold text-blue-600">8</p>
              </div>
              <CheckCircle className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Team Utilization</p>
                <p className="text-2xl font-bold text-green-600">86%</p>
              </div>
              <Users className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">This Week</p>
                <p className="text-2xl font-bold text-orange-600">12</p>
              </div>
              <Calendar className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Overdue Tasks</p>
                <p className="text-2xl font-bold text-red-600">3</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      {viewMode === 'calendar' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Project Schedule</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockScheduleData.map((item) => (
                    <div key={item.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-medium">{item.project}</h4>
                        <div className="flex gap-2">
                          <Badge className={getPriorityColor(item.priority)}>
                            {item.priority}
                          </Badge>
                          <Badge className={getStatusColor(item.status)}>
                            {item.status}
                          </Badge>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                        <div>
                          <span className="font-medium">Phase:</span> {item.phase}
                        </div>
                        <div>
                          <span className="font-medium">Team:</span> {item.team}
                        </div>
                        <div>
                          <span className="font-medium">Start:</span> {item.startDate}
                        </div>
                        <div>
                          <span className="font-medium">End:</span> {item.endDate}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader>
                <CardTitle>Upcoming Milestones</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-2 border rounded">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Site Survey Completion</p>
                      <p className="text-xs text-gray-500">Tomorrow</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 p-2 border rounded">
                    <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Fabrication Start</p>
                      <p className="text-xs text-gray-500">Jan 26</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 p-2 border rounded">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Installation Phase</p>
                      <p className="text-xs text-gray-500">Jan 28</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {viewMode === 'resource' && (
        <Card>
          <CardHeader>
            <CardTitle>Resource Utilization</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {resourceData.map((resource, index) => (
                <div key={index} className="border rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-medium">{resource.name}</h4>
                    <div className="text-sm text-gray-600">
                      {resource.available} available / {resource.total} total
                    </div>
                  </div>
                  
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full ${
                        resource.utilization > 90 ? 'bg-red-500' :
                        resource.utilization > 75 ? 'bg-yellow-500' : 'bg-green-500'
                      }`}
                      style={{ width: `${resource.utilization}%` }}
                    ></div>
                  </div>
                  
                  <div className="flex justify-between items-center mt-2 text-sm">
                    <span className="text-gray-600">Utilization</span>
                    <span className={`font-medium ${
                      resource.utilization > 90 ? 'text-red-600' :
                      resource.utilization > 75 ? 'text-yellow-600' : 'text-green-600'
                    }`}>
                      {resource.utilization}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {viewMode === 'gantt' && (
        <Card>
          <CardHeader>
            <CardTitle>Gantt Chart View</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12">
              <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Gantt Chart</h3>
              <p className="text-gray-600">Interactive Gantt chart visualization would be implemented here</p>
              <p className="text-sm text-gray-500 mt-2">Features: Timeline view, dependencies, critical path, resource allocation</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
