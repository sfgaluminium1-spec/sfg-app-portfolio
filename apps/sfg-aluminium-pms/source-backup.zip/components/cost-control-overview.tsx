
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  AlertTriangle,
  CheckCircle,
  BarChart3,
  PieChart,
  Calculator,
  Target,
  Clock
} from 'lucide-react';

const projectCosts = [
  {
    id: '1',
    name: 'Office Complex Phase 2',
    budget: 125000,
    actualCost: 98500,
    variance: -26500,
    variancePercent: -21.2,
    status: 'under',
    completion: 65
  },
  {
    id: '2',
    name: 'Retail Park Extension',
    budget: 89000,
    actualCost: 94200,
    variance: 5200,
    variancePercent: 5.8,
    status: 'over',
    completion: 40
  },
  {
    id: '3',
    name: 'Hospital Wing Curtain Wall',
    budget: 245000,
    actualCost: 238900,
    variance: -6100,
    variancePercent: -2.5,
    status: 'under',
    completion: 85
  },
  {
    id: '4',
    name: 'School Sports Hall',
    budget: 67000,
    actualCost: 12400,
    variance: -54600,
    variancePercent: -81.5,
    status: 'under',
    completion: 10
  }
];

const costBreakdown = [
  { category: 'Materials', budgeted: 180000, actual: 172000, variance: -8000 },
  { category: 'Labor', budgeted: 145000, actual: 156000, variance: 11000 },
  { category: 'Equipment', budgeted: 85000, actual: 81000, variance: -4000 },
  { category: 'Overhead', budgeted: 116000, actual: 135000, variance: 19000 },
];

export function CostControlOverview() {
  const [viewMode, setViewMode] = useState<'projects' | 'categories' | 'variance'>('projects');

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-GB', { 
      style: 'currency', 
      currency: 'GBP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getVarianceColor = (variance: number) => {
    if (variance > 0) return 'text-red-600';
    if (variance < 0) return 'text-green-600';
    return 'text-gray-600';
  };

  const getVarianceBadgeColor = (status: string) => {
    switch (status) {
      case 'under': return 'bg-green-100 text-green-800';
      case 'over': return 'bg-red-100 text-red-800';
      case 'on-budget': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const totalBudget = projectCosts.reduce((sum, project) => sum + project.budget, 0);
  const totalActual = projectCosts.reduce((sum, project) => sum + project.actualCost, 0);
  const totalVariance = totalActual - totalBudget;
  const variancePercent = (totalVariance / totalBudget) * 100;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Cost Control & Budget Tracking</h1>
        <p className="text-gray-600 mt-2">Monitor project budgets, track variances, and analyze cost performance</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Budget</p>
                <p className="text-2xl font-bold text-blue-600">{formatCurrency(totalBudget)}</p>
              </div>
              <Target className="h-8 w-8 text-blue-600" />
            </div>
            <div className="mt-2 text-xs text-gray-500">
              Across {projectCosts.length} active projects
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Actual Costs</p>
                <p className="text-2xl font-bold text-orange-600">{formatCurrency(totalActual)}</p>
              </div>
              <DollarSign className="h-8 w-8 text-orange-600" />
            </div>
            <div className="mt-2 text-xs text-gray-500">
              Current spending to date
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Variance</p>
                <p className={`text-2xl font-bold ${getVarianceColor(totalVariance)}`}>
                  {formatCurrency(totalVariance)}
                </p>
              </div>
              {totalVariance >= 0 ? (
                <TrendingUp className="h-8 w-8 text-red-600" />
              ) : (
                <TrendingDown className="h-8 w-8 text-green-600" />
              )}
            </div>
            <div className="mt-2 text-xs text-gray-500">
              {variancePercent.toFixed(1)}% vs budget
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Projects Over Budget</p>
                <p className="text-2xl font-bold text-red-600">
                  {projectCosts.filter(p => p.status === 'over').length}
                </p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-600" />
            </div>
            <div className="mt-2 text-xs text-gray-500">
              Require immediate attention
            </div>
          </CardContent>
        </Card>
      </div>

      {/* View Mode Tabs */}
      <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg w-fit">
        <Button
          variant={viewMode === 'projects' ? 'default' : 'ghost'}
          onClick={() => setViewMode('projects')}
          className="flex items-center gap-2"
        >
          <BarChart3 className="h-4 w-4" />
          By Project
        </Button>
        <Button
          variant={viewMode === 'categories' ? 'default' : 'ghost'}
          onClick={() => setViewMode('categories')}
          className="flex items-center gap-2"
        >
          <PieChart className="h-4 w-4" />
          By Category
        </Button>
        <Button
          variant={viewMode === 'variance' ? 'default' : 'ghost'}
          onClick={() => setViewMode('variance')}
          className="flex items-center gap-2"
        >
          <TrendingUp className="h-4 w-4" />
          Variance Analysis
        </Button>
      </div>

      {/* Content */}
      {viewMode === 'projects' && (
        <Card>
          <CardHeader>
            <CardTitle>Project Cost Tracking</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Project
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Budget
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actual Cost
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Variance
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Completion
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {projectCosts.map((project) => (
                    <tr key={project.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{project.name}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{formatCurrency(project.budget)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{formatCurrency(project.actualCost)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className={`text-sm font-medium ${getVarianceColor(project.variance)}`}>
                          {formatCurrency(project.variance)}
                          <div className="text-xs text-gray-500">
                            ({project.variancePercent.toFixed(1)}%)
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="text-sm text-gray-900 mr-2">{project.completion}%</div>
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ width: `${project.completion}%` }}
                            />
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Badge className={getVarianceBadgeColor(project.status)}>
                          {project.status === 'under' ? 'Under Budget' : 
                           project.status === 'over' ? 'Over Budget' : 'On Budget'}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {viewMode === 'categories' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Cost Breakdown by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {costBreakdown.map((category, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium">{category.category}</h4>
                      <Badge className={getVarianceBadgeColor(category.variance < 0 ? 'under' : 'over')}>
                        {formatCurrency(category.variance)}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Budgeted:</span>
                        <span className="float-right font-medium">{formatCurrency(category.budgeted)}</span>
                      </div>
                      <div>
                        <span className="text-gray-600">Actual:</span>
                        <span className="float-right font-medium">{formatCurrency(category.actual)}</span>
                      </div>
                    </div>
                    
                    <div className="mt-3">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            category.variance > 0 ? 'bg-red-500' : 'bg-green-500'
                          }`}
                          style={{ 
                            width: `${Math.min((category.actual / category.budgeted) * 100, 100)}%` 
                          }}
                        />
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        {((category.actual / category.budgeted) * 100).toFixed(1)}% of budget used
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>SFG Cost Control Rules</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border rounded-lg p-4 bg-blue-50">
                  <h4 className="font-medium text-blue-900 mb-2">Daily Overhead Target</h4>
                  <div className="text-2xl font-bold text-blue-700">£2,500</div>
                  <p className="text-sm text-blue-600 mt-1">Required daily margin to cover overhead</p>
                </div>

                <div className="border rounded-lg p-4 bg-green-50">
                  <h4 className="font-medium text-green-900 mb-2">Standard Margins</h4>
                  <div className="space-y-1 text-sm text-green-800">
                    <div className="flex justify-between">
                      <span>Supply & Install:</span>
                      <span className="font-medium">45%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Supply Only:</span>
                      <span className="font-medium">30%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Maintenance:</span>
                      <span className="font-medium">10%</span>
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg p-4 bg-yellow-50">
                  <h4 className="font-medium text-yellow-900 mb-2">Alert Thresholds</h4>
                  <div className="space-y-1 text-sm text-yellow-800">
                    <div className="flex justify-between">
                      <span>Budget Variance:</span>
                      <span className="font-medium">±5%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Overhead Coverage:</span>
                      <span className="font-medium">&lt;100%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Margin Drop:</span>
                      <span className="font-medium">&gt;5%</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {viewMode === 'variance' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Variance Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Variance Analysis Chart</h3>
                <p className="text-gray-600">Interactive variance trend visualization would be displayed here</p>
                <p className="text-sm text-gray-500 mt-2">Showing budget vs actual over time periods</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Cost Performance Indicators</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-green-100 rounded-lg">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium">Cost Performance Index</p>
                      <p className="text-sm text-gray-600">EV/AC Ratio</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-green-600">1.08</div>
                    <div className="text-xs text-gray-500">Above 1.0 = Good</div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <Calculator className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium">Budget Variance</p>
                      <p className="text-sm text-gray-600">Budget vs Actual</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-green-600">-3.2%</div>
                    <div className="text-xs text-gray-500">Under budget</div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-orange-100 rounded-lg">
                      <Clock className="h-5 w-5 text-orange-600" />
                    </div>
                    <div>
                      <p className="font-medium">Schedule Performance</p>
                      <p className="text-sm text-gray-600">EV/PV Ratio</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-orange-600">0.94</div>
                    <div className="text-xs text-gray-500">Behind schedule</div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-red-100 rounded-lg">
                      <AlertTriangle className="h-5 w-5 text-red-600" />
                    </div>
                    <div>
                      <p className="font-medium">Risk Assessment</p>
                      <p className="text-sm text-gray-600">Cost overrun probability</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-red-600">Medium</div>
                    <div className="text-xs text-gray-500">Monitor closely</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
