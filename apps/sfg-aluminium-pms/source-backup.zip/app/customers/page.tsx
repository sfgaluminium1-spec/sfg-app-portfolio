import { DashboardLayout } from '@/components/dashboard-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { UserCheck, Plus, TrendingUp, Users } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

export default function CustomersPage() {
  const customers = [
    { id: 'CUST-001', name: 'ABC Manufacturing Ltd', tier: 'Corporate', credit: 100000, balance: 45000, paymentTerms: 30, projects: 12 },
    { id: 'CUST-002', name: 'XYZ Construction', tier: 'Standard', credit: 50000, balance: 28500, paymentTerms: 30, projects: 8 },
    { id: 'CUST-003', name: 'Premium Developers', tier: 'Premium', credit: 150000, balance: 67000, paymentTerms: 45, projects: 15 },
    { id: 'CUST-004', name: 'Standard Projects Ltd', tier: 'Standard', credit: 30000, balance: 15200, paymentTerms: 30, projects: 5 },
    { id: 'CUST-005', name: 'Elite Properties', tier: 'VIP', credit: 250000, balance: 89000, paymentTerms: 60, projects: 24 },
  ];

  const tierColors: Record<string, string> = {
    'Residential': 'bg-gray-100 text-gray-800',
    'Trade': 'bg-blue-100 text-blue-800',
    'Standard': 'bg-green-100 text-green-800',
    'Corporate': 'bg-purple-100 text-purple-800',
    'Premium': 'bg-orange-100 text-orange-800',
    'VIP': 'bg-red-100 text-red-800',
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Customer Management</h1>
            <p className="text-gray-600 mt-1">
              Manage customer tiers, credit limits, and payment terms
            </p>
          </div>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Add Customer
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Customers</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">247</div>
              <p className="text-xs text-muted-foreground">Active accounts</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Credit Extended</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">£12.3M</div>
              <p className="text-xs text-muted-foreground">Total credit limits</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Outstanding</CardTitle>
              <UserCheck className="h-4 w-4 text-yellow-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">£2.4M</div>
              <p className="text-xs text-muted-foreground">Current balances</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">VIP/Premium</CardTitle>
              <UserCheck className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">42</div>
              <p className="text-xs text-muted-foreground">Top tier customers</p>
            </CardContent>
          </Card>
        </div>

        {/* Customers Table */}
        <Card>
          <CardHeader>
            <CardTitle>Customer List</CardTitle>
            <CardDescription>All customers with tier and credit information</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Customer ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Tier</TableHead>
                  <TableHead>Credit Limit</TableHead>
                  <TableHead>Balance</TableHead>
                  <TableHead>Payment Terms</TableHead>
                  <TableHead>Projects</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {customers.map((customer) => (
                  <TableRow key={customer.id}>
                    <TableCell className="font-mono">{customer.id}</TableCell>
                    <TableCell className="font-semibold">{customer.name}</TableCell>
                    <TableCell>
                      <Badge className={tierColors[customer.tier]}>
                        {customer.tier}
                      </Badge>
                    </TableCell>
                    <TableCell>£{customer.credit.toLocaleString()}</TableCell>
                    <TableCell>£{customer.balance.toLocaleString()}</TableCell>
                    <TableCell>{customer.paymentTerms} days</TableCell>
                    <TableCell>{customer.projects}</TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm">View</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
