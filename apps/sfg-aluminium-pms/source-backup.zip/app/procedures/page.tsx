import { DashboardLayout } from '@/components/dashboard-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollText, Plus, Clock } from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

export default function ProceduresPage() {
  const procedures = [
    {
      id: 'PROC-001',
      title: 'Standard Workflow: Enquiry to Completion',
      category: 'Operations',
      department: 'All',
      version: '2.1',
      steps: [
        { num: 1, title: 'Receive and Log Enquiry', duration: '15 mins', resources: 'Office admin, CRM system' },
        { num: 2, title: 'Issue Letter of Intent', duration: '30 mins', resources: 'Sales team, template documents' },
        { num: 3, title: 'Prepare Quotation', duration: '4 hours', resources: 'Estimator, pricing database, CAD' },
        { num: 4, title: 'Submit Proposal to Client', duration: '30 mins', resources: 'Sales team, email system' },
        { num: 5, title: 'Generate Deposit Invoice', duration: '20 mins', resources: 'Accounts, invoicing system' },
      ]
    },
    {
      id: 'PROC-002',
      title: 'Fabrication Standard Operating Procedure',
      category: 'Manufacturing',
      department: 'Factory',
      version: '1.8',
      steps: [
        { num: 1, title: 'Receive and Check Materials', duration: '1 hour', resources: 'Warehouse staff, checklist' },
        { num: 2, title: 'CNC Programming and Setup', duration: '2 hours', resources: 'CNC operator, CAD files' },
        { num: 3, title: 'Cut and Machine Profiles', duration: '6 hours', resources: 'CNC machine, operator' },
        { num: 4, title: 'Quality Inspection', duration: '1 hour', resources: 'QC team, measuring tools' },
        { num: 5, title: 'Assembly and Fabrication', duration: '8 hours', resources: 'Fabricators, welding equipment' },
      ]
    },
    {
      id: 'PROC-003',
      title: 'Installation Process and Safety',
      category: 'Installation',
      department: 'Site Operations',
      version: '2.0',
      steps: [
        { num: 1, title: 'Site Survey and Risk Assessment', duration: '3 hours', resources: 'Site manager, RAMS forms' },
        { num: 2, title: 'Mobilize Equipment and Team', duration: '4 hours', resources: 'Transport, tools, PPE' },
        { num: 3, title: 'Install Curtain Wall Frames', duration: '5 days', resources: 'Installation team, scissor lift' },
        { num: 4, title: 'Glazing and Sealing', duration: '3 days', resources: 'Glaziers, sealant equipment' },
        { num: 5, title: 'Snagging and Final QA', duration: '1 day', resources: 'Site manager, client, checklist' },
      ]
    },
    {
      id: 'PROC-004',
      title: 'Maintenance and Repairs Procedure',
      category: 'Maintenance',
      department: 'Service',
      version: '1.5',
      steps: [
        { num: 1, title: 'Schedule Maintenance Visit', duration: '30 mins', resources: 'Service coordinator, calendar' },
        { num: 2, title: 'Conduct Site Inspection', duration: '2 hours', resources: 'Service technician, checklist' },
        { num: 3, title: 'Perform Lubrication and Adjustments', duration: '4 hours', resources: 'Lubricants, tools' },
        { num: 4, title: 'Replace Worn Components', duration: '3 hours', resources: 'Spare parts, installation tools' },
        { num: 5, title: 'Complete Service Report', duration: '1 hour', resources: 'Technician, reporting system' },
      ]
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Company Procedures</h1>
            <p className="text-gray-600 mt-1">
              Comprehensive step-by-step procedures across all operations
            </p>
          </div>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            New Procedure
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Procedures</CardTitle>
              <ScrollText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">47</div>
              <p className="text-xs text-muted-foreground">Documented processes</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Categories</CardTitle>
              <ScrollText className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">8</div>
              <p className="text-xs text-muted-foreground">Process categories</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Steps</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">867</div>
              <p className="text-xs text-muted-foreground">Individual steps</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Last Updated</CardTitle>
              <ScrollText className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12</div>
              <p className="text-xs text-muted-foreground">This month</p>
            </CardContent>
          </Card>
        </div>

        {/* Procedures */}
        <Card>
          <CardHeader>
            <CardTitle>All Procedures</CardTitle>
            <CardDescription>Expandable step-by-step procedures</CardDescription>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible className="w-full">
              {procedures.map((proc) => (
                <AccordionItem key={proc.id} value={proc.id}>
                  <AccordionTrigger>
                    <div className="flex items-center justify-between w-full pr-4">
                      <div className="flex items-center space-x-3">
                        <span className="font-semibold">{proc.title}</span>
                        <Badge variant="outline">{proc.category}</Badge>
                        <Badge variant="outline" className="text-xs">v{proc.version}</Badge>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4 pt-4">
                      <div className="flex items-center space-x-6 text-sm text-gray-600 mb-4">
                        <span><strong>Department:</strong> {proc.department}</span>
                        <span><strong>ID:</strong> {proc.id}</span>
                      </div>
                      <div className="space-y-3">
                        {proc.steps.map((step) => (
                          <div key={step.num} className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg">
                            <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-semibold flex-shrink-0">
                              {step.num}
                            </div>
                            <div className="flex-1">
                              <p className="font-semibold text-gray-900">{step.title}</p>
                              <div className="mt-2 text-sm text-gray-600 space-y-1">
                                <p><strong>Duration:</strong> {step.duration}</p>
                                <p><strong>Resources:</strong> {step.resources}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
