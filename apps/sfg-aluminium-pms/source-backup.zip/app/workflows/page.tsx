import { DashboardLayout } from '@/components/dashboard-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { GitBranch, Clock, CheckCircle } from 'lucide-react';

export default function WorkflowsPage() {
  const workflowSteps = [
    { step: 1, name: 'Enquiry Received', status: 'completed', duration: '1-2 days' },
    { step: 2, name: 'Quotation Preparation', status: 'completed', duration: '2-3 days' },
    { step: 3, name: 'Deposit Invoice', status: 'completed', duration: '1 day' },
    { step: 4, name: 'Purchase Order Receipt', status: 'active', duration: '1-5 days' },
    { step: 5, name: 'Project Kick-Off', status: 'pending', duration: '1 day' },
    { step: 6, name: 'Materials Procurement', status: 'pending', duration: '5-10 days' },
    { step: 7, name: 'RAMS Preparation', status: 'pending', duration: '2-3 days' },
    { step: 8, name: 'Site Survey', status: 'pending', duration: '1 day' },
    { step: 9, name: 'Drawings Approval', status: 'pending', duration: '3-5 days' },
    { step: 10, name: 'Fabrication', status: 'pending', duration: '10-15 days' },
    { step: 11, name: 'Powder Coating', status: 'pending', duration: '3-5 days' },
    { step: 12, name: 'Packing & Delivery', status: 'pending', duration: '1-2 days' },
    { step: 13, name: 'Site Mobilisation', status: 'pending', duration: '1 day' },
    { step: 14, name: 'Frame Installation', status: 'pending', duration: '5-10 days' },
    { step: 15, name: 'Glazing & Cappings', status: 'pending', duration: '3-5 days' },
    { step: 16, name: 'Snagging & QA', status: 'pending', duration: '1-2 days' },
    { step: 17, name: 'O&M Manuals', status: 'pending', duration: '1 day' },
    { step: 18, name: 'Practical Completion', status: 'pending', duration: '1 day' },
    { step: 19, name: 'Invoicing & Payment', status: 'pending', duration: '30-45 days' },
    { step: 20, name: 'Retention Release', status: 'pending', duration: '6-12 months' },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Workflow Orchestration</h1>
          <p className="text-gray-600 mt-1">
            20-step workflow from enquiry to retention release
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Steps</CardTitle>
              <GitBranch className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">20</div>
              <p className="text-xs text-muted-foreground">Standard workflow</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg Duration</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">60-90</div>
              <p className="text-xs text-muted-foreground">Days to completion</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Projects</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">156</div>
              <p className="text-xs text-muted-foreground">In various stages</p>
            </CardContent>
          </Card>
        </div>

        {/* Workflow Steps */}
        <Card>
          <CardHeader>
            <CardTitle>Standard Workflow Steps</CardTitle>
            <CardDescription>Complete workflow from enquiry to retention</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {workflowSteps.map((item) => (
                <div key={item.step} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center space-x-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                      item.status === 'completed' ? 'bg-green-100 text-green-700' :
                      item.status === 'active' ? 'bg-blue-100 text-blue-700' :
                      'bg-gray-100 text-gray-500'
                    }`}>
                      {item.step}
                    </div>
                    <div>
                      <p className="font-semibold">{item.name}</p>
                      <p className="text-sm text-gray-500">Duration: {item.duration}</p>
                    </div>
                  </div>
                  <Badge variant="outline" className={
                    item.status === 'completed' ? 'bg-green-50 text-green-700 border-green-200' :
                    item.status === 'active' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                    'bg-gray-50 text-gray-500 border-gray-200'
                  }>
                    {item.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
