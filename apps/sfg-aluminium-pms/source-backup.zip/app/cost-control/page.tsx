
import { DashboardLayout } from '@/components/dashboard-layout';
import { CostControlOverview } from '@/components/cost-control-overview';

export default function CostControlPage() {
  return (
    <DashboardLayout>
      <CostControlOverview />
    </DashboardLayout>
  );
}
