import { DashboardLayout } from '@/components/dashboard-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Hash, Plus, FileText, TrendingUp } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

export default function BaseNumbersPage() {
  const baseNumbers = [
    { baseNumber: 24001, stage: 'Payment', customer: 'ABC Manufacturing Ltd', value: 45000, status: 'Active', created: '2025-10-15' },
    { baseNumber: 24002, stage: 'Invoice', customer: 'XYZ Construction', value: 28500, status: 'Active', created: '2025-10-18' },
    { baseNumber: 24003, stage: 'Order', customer: 'Premium Developers', value: 67000, status: 'Active', created: '2025-10-20' },
    { baseNumber: 24004, stage: 'Quotation', customer: 'Standard Projects Ltd', value: 15200, status: 'Active', created: '2025-10-22' },
    { baseNumber: 24005, stage: 'Enquiry', customer: 'Elite Properties', value: 89000, status: 'Active', created: '2025-10-25' },
  ];

  const stageColors: Record<string, string> = {
    'Enquiry': 'bg-blue-100 text-blue-800',
    'Quotation': 'bg-purple-100 text-purple-800',
    'Order': 'bg-yellow-100 text-yellow-800',
    'Invoice': 'bg-orange-100 text-orange-800',
    'Delivery': 'bg-green-100 text-green-800',
    'Payment': 'bg-emerald-100 text-emerald-800',
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Base Number Management</h1>
            <p className="text-gray-600 mt-1">
              Track and manage immutable base numbers across document lifecycle
            </p>
          </div>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Generate Base Number
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Base Numbers</CardTitle>
              <Hash className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1,247</div>
              <p className="text-xs text-muted-foreground">Since 2024</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active</CardTitle>
              <FileText className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">156</div>
              <p className="text-xs text-muted-foreground">In progress</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Value</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">£2.4M</div>
              <p className="text-xs text-muted-foreground">Active pipeline</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Completed</CardTitle>
              <FileText className="h-4 w-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1,091</div>
              <p className="text-xs text-muted-foreground">Fully processed</p>
            </CardContent>
          </Card>
        </div>

        {/* Base Numbers Table */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Base Numbers</CardTitle>
            <CardDescription>Latest generated base numbers and their current stage</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Base Number</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Current Stage</TableHead>
                  <TableHead>Value</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {baseNumbers.map((item) => (
                  <TableRow key={item.baseNumber}>
                    <TableCell className="font-mono font-semibold">
                      {item.baseNumber}
                    </TableCell>
                    <TableCell>{item.customer}</TableCell>
                    <TableCell>
                      <Badge className={stageColors[item.stage] || 'bg-gray-100 text-gray-800'}>
                        {item.stage}
                      </Badge>
                    </TableCell>
                    <TableCell>£{item.value.toLocaleString()}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        {item.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{item.created}</TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm">View</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
