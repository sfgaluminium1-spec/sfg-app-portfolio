import { DashboardLayout } from '@/components/dashboard-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FileStack, FileText, FileCheck, Download } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';

export default function DocumentsLifecyclePage() {
  const docPrefixes = [
    { prefix: 'ENQ', stage: 'Enquiry', count: 45, color: 'bg-blue-500' },
    { prefix: 'QUO', stage: 'Quotation', count: 38, color: 'bg-purple-500' },
    { prefix: 'PO', stage: 'Purchase Order', count: 32, color: 'bg-yellow-500' },
    { prefix: 'INV', stage: 'Invoice', count: 28, color: 'bg-orange-500' },
    { prefix: 'DEL', stage: 'Delivery', count: 25, color: 'bg-green-500' },
    { prefix: 'PAID', stage: 'Payment', count: 22, color: 'bg-emerald-500' },
  ];

  const documents = [
    { ref: 'ENQ-24001', type: 'Enquiry', customer: 'ABC Manufacturing', date: '2025-10-25', status: 'Open' },
    { ref: 'QUO-24001', type: 'Quotation', customer: 'ABC Manufacturing', date: '2025-10-26', status: 'Sent' },
    { ref: 'PO-24002', type: 'Purchase Order', customer: 'XYZ Construction', date: '2025-10-24', status: 'Confirmed' },
    { ref: 'INV-24003', type: 'Invoice', customer: 'Premium Developers', date: '2025-10-23', status: 'Issued' },
    { ref: 'DEL-24004', type: 'Delivery Note', customer: 'Standard Projects', date: '2025-10-22', status: 'Completed' },
    { ref: 'PAID-24001', type: 'Payment Receipt', customer: 'Elite Properties', date: '2025-10-20', status: 'Received' },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Document Lifecycle Management</h1>
          <p className="text-gray-600 mt-1">
            Track document prefixes and stage transitions with full audit trail
          </p>
        </div>

        {/* Document Prefix Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {docPrefixes.map((doc) => (
            <Card key={doc.prefix}>
              <CardHeader className="pb-3">
                <div className={`w-12 h-12 rounded-lg ${doc.color} flex items-center justify-center text-white font-bold text-lg`}>
                  {doc.prefix}
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{doc.count}</div>
                <p className="text-sm text-gray-600">{doc.stage}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Documents Table */}
        <Card>
          <CardHeader>
            <CardTitle>Document Timeline</CardTitle>
            <CardDescription>All documents across lifecycle stages</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all" className="w-full">
              <TabsList>
                <TabsTrigger value="all">All Documents</TabsTrigger>
                <TabsTrigger value="enquiry">Enquiry</TabsTrigger>
                <TabsTrigger value="quotation">Quotation</TabsTrigger>
                <TabsTrigger value="order">Order</TabsTrigger>
                <TabsTrigger value="invoice">Invoice</TabsTrigger>
              </TabsList>
              <TabsContent value="all" className="mt-4">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Reference</TableHead>
                      <TableHead>Document Type</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {documents.map((doc) => (
                      <TableRow key={doc.ref}>
                        <TableCell className="font-mono font-semibold">{doc.ref}</TableCell>
                        <TableCell>{doc.type}</TableCell>
                        <TableCell>{doc.customer}</TableCell>
                        <TableCell>{doc.date}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{doc.status}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="sm">
                              <FileText className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Download className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
