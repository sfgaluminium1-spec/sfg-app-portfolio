
import { DashboardLayout } from '@/components/dashboard-layout';
import { TasksManagement } from '@/components/tasks-management';

export default function TasksPage() {
  return (
    <DashboardLayout>
      <TasksManagement />
    </DashboardLayout>
  );
}
