import { DashboardLayout } from '@/components/dashboard-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Zap, Plus, Activity } from 'lucide-react';

export default function McpConfigPage() {
  const mcpServers = [
    { name: 'SFG Orchestrator', status: 'active', tools: 12, connections: 5, lastSync: '1 min ago' },
    { name: 'AgentPass Workspace', status: 'active', tools: 8, connections: 3, lastSync: '5 mins ago' },
    { name: 'Comet Core MCP', status: 'active', tools: 15, connections: 4, lastSync: '2 mins ago' },
    { name: 'Document Processor', status: 'inactive', tools: 6, connections: 0, lastSync: 'Never' },
  ];

  const tools = [
    { name: 'generate_base_number', server: 'SFG Orchestrator', description: 'Generate new base number with validation' },
    { name: 'validate_base_number', server: 'SFG Orchestrator', description: 'Validate base number format and status' },
    { name: 'advance_document_stage', server: 'SFG Orchestrator', description: 'Advance document to next lifecycle stage' },
    { name: 'calculate_customer_tier', server: 'SFG Orchestrator', description: 'Calculate customer tier based on criteria' },
    { name: 'enforce_staff_permissions', server: 'AgentPass Workspace', description: 'Check and enforce staff tier permissions' },
    { name: 'workflow_orchestration', server: 'SFG Orchestrator', description: 'Start and manage workflow execution' },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">MCP Configuration</h1>
            <p className="text-gray-600 mt-1">
              Model Context Protocol server orchestration and tool management
            </p>
          </div>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Add MCP Server
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">MCP Servers</CardTitle>
              <Zap className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">4</div>
              <p className="text-xs text-muted-foreground">Configured servers</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active</CardTitle>
              <Activity className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3</div>
              <p className="text-xs text-muted-foreground">Running servers</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Tools</CardTitle>
              <Zap className="h-4 w-4 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">41</div>
              <p className="text-xs text-muted-foreground">Available tools</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Connections</CardTitle>
              <Activity className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12</div>
              <p className="text-xs text-muted-foreground">Active connections</p>
            </CardContent>
          </Card>
        </div>

        {/* MCP Servers */}
        <Card>
          <CardHeader>
            <CardTitle>MCP Servers</CardTitle>
            <CardDescription>Configured Model Context Protocol servers</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mcpServers.map((server) => (
                <div key={server.name} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center space-x-4">
                    <Zap className="h-8 w-8 text-purple-500" />
                    <div>
                      <p className="font-semibold">{server.name}</p>
                      <p className="text-sm text-gray-500">
                        {server.tools} tools • {server.connections} connections • Last sync: {server.lastSync}
                      </p>
                    </div>
                  </div>
                  <Badge variant="outline" className={
                    server.status === 'active' 
                      ? 'bg-green-50 text-green-700 border-green-200' 
                      : 'bg-gray-50 text-gray-500 border-gray-200'
                  }>
                    {server.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Tools */}
        <Card>
          <CardHeader>
            <CardTitle>Available Tools</CardTitle>
            <CardDescription>MCP tools for cross-app orchestration</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {tools.map((tool) => (
                <div key={tool.name} className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <code className="text-sm font-mono text-blue-600">{tool.name}</code>
                    <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                      {tool.server}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">{tool.description}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
