import { DashboardLayout } from '@/components/dashboard-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Grid3x3, Plus, Activity, AlertCircle, CheckCircle } from 'lucide-react';

export default function AppRegistryPage() {
  const apps = [
    {
      name: 'Comet Core',
      status: 'production',
      version: '2.1.0',
      description: 'Core business logic and API orchestration',
      health: 'healthy',
      endpoints: 45,
      lastSync: '2 mins ago'
    },
    {
      name: 'Brand Engine',
      status: 'production',
      version: '1.8.3',
      description: 'Brand assets and design system management',
      health: 'healthy',
      endpoints: 23,
      lastSync: '5 mins ago'
    },
    {
      name: 'AI-AutoStack',
      status: 'beta',
      version: '0.9.2',
      description: 'AI-powered automation and optimization',
      health: 'warning',
      endpoints: 18,
      lastSync: '10 mins ago'
    },
    {
      name: 'ESP Platform',
      status: 'production',
      version: '3.0.1',
      description: 'Enterprise service platform integration',
      health: 'healthy',
      endpoints: 67,
      lastSync: '1 min ago'
    },
    {
      name: 'QuickSpace',
      status: 'development',
      version: '0.5.0',
      description: 'Rapid workspace provisioning and management',
      health: 'offline',
      endpoints: 12,
      lastSync: 'Never'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'production': return 'bg-green-500';
      case 'beta': return 'bg-yellow-500';
      case 'development': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const getHealthIcon = (health: string) => {
    switch (health) {
      case 'healthy': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'warning': return <AlertCircle className="h-5 w-5 text-yellow-500" />;
      case 'offline': return <AlertCircle className="h-5 w-5 text-red-500" />;
      default: return <Activity className="h-5 w-5 text-gray-500" />;
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Application Registry</h1>
            <p className="text-gray-600 mt-1">
              Manage and monitor all SFG Aluminium ecosystem applications
            </p>
          </div>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Register App
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Apps</CardTitle>
              <Grid3x3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">5</div>
              <p className="text-xs text-muted-foreground">Across all environments</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Production</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3</div>
              <p className="text-xs text-muted-foreground">Live applications</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">API Endpoints</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">165</div>
              <p className="text-xs text-muted-foreground">Total endpoints</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Health Status</CardTitle>
              <AlertCircle className="h-4 w-4 text-yellow-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1</div>
              <p className="text-xs text-muted-foreground">Needs attention</p>
            </CardContent>
          </Card>
        </div>

        {/* Applications List */}
        <div className="grid grid-cols-1 gap-6">
          {apps.map((app) => (
            <Card key={app.name}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3">
                      <CardTitle className="text-xl">{app.name}</CardTitle>
                      <Badge className={getStatusColor(app.status)}>
                        {app.status}
                      </Badge>
                      {getHealthIcon(app.health)}
                    </div>
                    <CardDescription className="mt-2">{app.description}</CardDescription>
                  </div>
                  <Button variant="outline" size="sm">View Details</Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-4 gap-4 text-sm">
                  <div>
                    <p className="text-gray-500">Version</p>
                    <p className="font-semibold">{app.version}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Endpoints</p>
                    <p className="font-semibold">{app.endpoints}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Last Sync</p>
                    <p className="font-semibold">{app.lastSync}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Health</p>
                    <p className="font-semibold capitalize">{app.health}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
