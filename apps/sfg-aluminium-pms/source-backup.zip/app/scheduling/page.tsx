
import { DashboardLayout } from '@/components/dashboard-layout';
import { SchedulingOverview } from '@/components/scheduling-overview';

export default function SchedulingPage() {
  return (
    <DashboardLayout>
      <SchedulingOverview />
    </DashboardLayout>
  );
}
