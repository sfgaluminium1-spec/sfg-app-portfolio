
import { DashboardLayout } from '@/components/dashboard-layout';
import { SettingsOverview } from '@/components/settings-overview';

export default function SettingsPage() {
  return (
    <DashboardLayout>
      <SettingsOverview />
    </DashboardLayout>
  );
}
