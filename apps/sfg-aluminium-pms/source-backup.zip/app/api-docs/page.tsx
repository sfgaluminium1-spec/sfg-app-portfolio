import { DashboardLayout } from '@/components/dashboard-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Globe, Lock, Unlock } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function ApiDocsPage() {
  const endpoints = [
    { method: 'POST', path: '/api/base-numbers/generate', auth: true, description: 'Generate new base number' },
    { method: 'GET', path: '/api/base-numbers/:id', auth: true, description: 'Get base number details' },
    { method: 'PUT', path: '/api/base-numbers/:id/advance', auth: true, description: 'Advance to next stage' },
    { method: 'POST', path: '/api/documents/create', auth: true, description: 'Create document reference' },
    { method: 'GET', path: '/api/documents/:ref', auth: true, description: 'Get document details' },
    { method: 'POST', path: '/api/customers/tier/calculate', auth: true, description: 'Calculate customer tier' },
    { method: 'GET', path: '/api/customers/:id', auth: true, description: 'Get customer details' },
    { method: 'POST', path: '/api/workflow/start', auth: true, description: 'Start new workflow' },
    { method: 'PUT', path: '/api/workflow/:id/advance', auth: true, description: 'Advance workflow step' },
    { method: 'GET', path: '/api/applications', auth: false, description: 'List all applications' },
  ];

  const methodColors: Record<string, string> = {
    'GET': 'bg-blue-100 text-blue-800',
    'POST': 'bg-green-100 text-green-800',
    'PUT': 'bg-yellow-100 text-yellow-800',
    'DELETE': 'bg-red-100 text-red-800',
    'PATCH': 'bg-purple-100 text-purple-800',
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">API Documentation</h1>
          <p className="text-gray-600 mt-1">
            Comprehensive API reference for SFG Aluminium Complete System
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Endpoints</CardTitle>
              <Globe className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">165</div>
              <p className="text-xs text-muted-foreground">Across all apps</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Public</CardTitle>
              <Unlock className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">23</div>
              <p className="text-xs text-muted-foreground">No auth required</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Protected</CardTitle>
              <Lock className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">142</div>
              <p className="text-xs text-muted-foreground">Auth required</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Webhooks</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">34</div>
              <p className="text-xs text-muted-foreground">Event subscriptions</p>
            </CardContent>
          </Card>
        </div>

        {/* API Endpoints */}
        <Card>
          <CardHeader>
            <CardTitle>API Endpoints</CardTitle>
            <CardDescription>REST API endpoints with authentication requirements</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all" className="w-full">
              <TabsList>
                <TabsTrigger value="all">All Endpoints</TabsTrigger>
                <TabsTrigger value="base">Base Numbers</TabsTrigger>
                <TabsTrigger value="docs">Documents</TabsTrigger>
                <TabsTrigger value="workflow">Workflow</TabsTrigger>
              </TabsList>
              <TabsContent value="all" className="mt-4">
                <div className="space-y-3">
                  {endpoints.map((endpoint, idx) => (
                    <div key={idx} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center space-x-4 flex-1">
                        <Badge className={methodColors[endpoint.method]}>
                          {endpoint.method}
                        </Badge>
                        <code className="text-sm font-mono text-gray-700">{endpoint.path}</code>
                      </div>
                      <div className="flex items-center space-x-4">
                        <p className="text-sm text-gray-600 hidden md:block">{endpoint.description}</p>
                        {endpoint.auth ? (
                          <div className="flex items-center gap-1" title="Requires authentication">
                            <Lock className="h-4 w-4 text-red-500" />
                          </div>
                        ) : (
                          <div className="flex items-center gap-1" title="Public endpoint">
                            <Unlock className="h-4 w-4 text-green-500" />
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Authentication */}
        <Card>
          <CardHeader>
            <CardTitle>Authentication</CardTitle>
            <CardDescription>API authentication methods</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-2">Bearer Token</h4>
                <p className="text-sm text-blue-800">Include JWT token in Authorization header</p>
                <code className="text-xs bg-white px-2 py-1 rounded mt-2 inline-block">
                  Authorization: Bearer YOUR_TOKEN_HERE
                </code>
              </div>
              <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                <h4 className="font-semibold text-purple-900 mb-2">API Key</h4>
                <p className="text-sm text-purple-800">Include API key in X-API-Key header</p>
                <code className="text-xs bg-white px-2 py-1 rounded mt-2 inline-block">
                  X-API-Key: YOUR_API_KEY_HERE
                </code>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
