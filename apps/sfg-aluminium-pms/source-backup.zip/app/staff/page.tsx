import { DashboardLayout } from '@/components/dashboard-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Shield, Plus, Users, Award } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

export default function StaffPage() {
  const staff = [
    { id: 'STF-001', name: 'John Smith', tier: 'Director', department: 'Management', quotingLimit: 500000, approvalLimit: 1000000, projects: 45 },
    { id: 'STF-002', name: 'Sarah Johnson', tier: 'Manager', department: 'Operations', quotingLimit: 250000, approvalLimit: 500000, projects: 32 },
    { id: 'STF-003', name: 'Mike Wilson', tier: 'Supervisor', department: 'Factory', quotingLimit: 100000, approvalLimit: 150000, projects: 28 },
    { id: 'STF-004', name: 'Emma Brown', tier: 'Senior Operative', department: 'Installation', quotingLimit: 50000, approvalLimit: 75000, projects: 18 },
    { id: 'STF-005', name: 'David Lee', tier: 'Operative', department: 'Fabrication', quotingLimit: 0, approvalLimit: 0, projects: 12 },
  ];

  const tierColors: Record<string, string> = {
    'Director': 'bg-red-100 text-red-800',
    'Senior Manager': 'bg-orange-100 text-orange-800',
    'Manager': 'bg-purple-100 text-purple-800',
    'Supervisor': 'bg-blue-100 text-blue-800',
    'Senior Operative': 'bg-green-100 text-green-800',
    'Operative': 'bg-gray-100 text-gray-800',
    'Apprentice': 'bg-yellow-100 text-yellow-800',
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Staff Management</h1>
            <p className="text-gray-600 mt-1">
              Manage staff tiers, permissions, and quoting limits
            </p>
          </div>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Add Staff Member
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Staff</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">87</div>
              <p className="text-xs text-muted-foreground">Active employees</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Management</CardTitle>
              <Award className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12</div>
              <p className="text-xs text-muted-foreground">Managers & directors</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Supervisors</CardTitle>
              <Shield className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">18</div>
              <p className="text-xs text-muted-foreground">Team leaders</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Operatives</CardTitle>
              <Users className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">57</div>
              <p className="text-xs text-muted-foreground">Field & factory staff</p>
            </CardContent>
          </Card>
        </div>

        {/* Staff Table */}
        <Card>
          <CardHeader>
            <CardTitle>Staff List</CardTitle>
            <CardDescription>All staff members with tier and permissions</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Staff ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Tier</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Quoting Limit</TableHead>
                  <TableHead>Approval Limit</TableHead>
                  <TableHead>Projects</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {staff.map((member) => (
                  <TableRow key={member.id}>
                    <TableCell className="font-mono">{member.id}</TableCell>
                    <TableCell className="font-semibold">{member.name}</TableCell>
                    <TableCell>
                      <Badge className={tierColors[member.tier]}>
                        {member.tier}
                      </Badge>
                    </TableCell>
                    <TableCell>{member.department}</TableCell>
                    <TableCell>
                      {member.quotingLimit > 0 ? `£${member.quotingLimit.toLocaleString()}` : 'None'}
                    </TableCell>
                    <TableCell>
                      {member.approvalLimit > 0 ? `£${member.approvalLimit.toLocaleString()}` : 'None'}
                    </TableCell>
                    <TableCell>{member.projects}</TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm">View</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
