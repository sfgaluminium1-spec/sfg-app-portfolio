
import { DashboardLayout } from '@/components/dashboard-layout';
import { ResourcesOverview } from '@/components/resources-overview';

export default function ResourcesPage() {
  return (
    <DashboardLayout>
      <ResourcesOverview />
    </DashboardLayout>
  );
}
