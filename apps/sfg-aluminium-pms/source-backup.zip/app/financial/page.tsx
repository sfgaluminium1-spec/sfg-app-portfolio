
import { DashboardLayout } from '@/components/dashboard-layout';
import { FinancialCalculator } from '@/components/financial-calculator';

export default function FinancialPage() {
  return (
    <DashboardLayout>
      <FinancialCalculator />
    </DashboardLayout>
  );
}
