import { DashboardLayout } from '@/components/dashboard-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Activity, CheckCircle, AlertTriangle, XCircle, Zap } from 'lucide-react';

export default function IntegrationHubPage() {
  const integrations = [
    { name: 'Comet Core ↔ Brand Engine', status: 'healthy', events: 1247, lastEvent: '2 mins ago', avgLatency: '45ms' },
    { name: 'ESP Platform ↔ Comet Core', status: 'healthy', events: 3429, lastEvent: '1 min ago', avgLatency: '38ms' },
    { name: 'AI-AutoStack ↔ QuickSpace', status: 'warning', events: 542, lastEvent: '15 mins ago', avgLatency: '156ms' },
    { name: 'Brand Engine ↔ QuickSpace', status: 'healthy', events: 892, lastEvent: '3 mins ago', avgLatency: '52ms' },
    { name: 'Comet Core ↔ Xero', status: 'error', events: 0, lastEvent: '2 hours ago', avgLatency: 'N/A' },
  ];

  const webhookActivity = [
    { event: 'customer.created', app: 'Comet Core', timestamp: '2 mins ago', status: 'delivered' },
    { event: 'quote.approved', app: 'ESP Platform', timestamp: '5 mins ago', status: 'delivered' },
    { event: 'project.started', app: 'Brand Engine', timestamp: '8 mins ago', status: 'delivered' },
    { event: 'invoice.issued', app: 'Comet Core', timestamp: '12 mins ago', status: 'failed' },
    { event: 'document.generated', app: 'AI-AutoStack', timestamp: '15 mins ago', status: 'delivered' },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'error': return <XCircle className="h-5 w-5 text-red-500" />;
      default: return <Activity className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'delivered': return <Badge className="bg-green-100 text-green-800">Delivered</Badge>;
      case 'failed': return <Badge className="bg-red-100 text-red-800">Failed</Badge>;
      case 'pending': return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Integration Hub</h1>
          <p className="text-gray-600 mt-1">
            Real-time monitoring of cross-app integrations and webhook delivery
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Integrations</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">5</div>
              <p className="text-xs text-muted-foreground">Cross-app connections</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Healthy</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3</div>
              <p className="text-xs text-muted-foreground">Operating normally</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Events Today</CardTitle>
              <Zap className="h-4 w-4 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">6,110</div>
              <p className="text-xs text-muted-foreground">Webhook deliveries</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg Latency</CardTitle>
              <Activity className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">58ms</div>
              <p className="text-xs text-muted-foreground">Response time</p>
            </CardContent>
          </Card>
        </div>

        {/* Integration Status */}
        <Card>
          <CardHeader>
            <CardTitle>Integration Status</CardTitle>
            <CardDescription>Real-time health monitoring of app integrations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {integrations.map((integration) => (
                <div key={integration.name} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center space-x-4 flex-1">
                    {getStatusIcon(integration.status)}
                    <div>
                      <p className="font-semibold">{integration.name}</p>
                      <p className="text-sm text-gray-500">
                        {integration.events.toLocaleString()} events • Last: {integration.lastEvent} • Latency: {integration.avgLatency}
                      </p>
                    </div>
                  </div>
                  <Badge variant="outline" className={
                    integration.status === 'healthy' ? 'bg-green-50 text-green-700 border-green-200' :
                    integration.status === 'warning' ? 'bg-yellow-50 text-yellow-700 border-yellow-200' :
                    'bg-red-50 text-red-700 border-red-200'
                  }>
                    {integration.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Webhook Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Webhook Activity</CardTitle>
            <CardDescription>Latest webhook deliveries across applications</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {webhookActivity.map((webhook, idx) => (
                <div key={idx} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3">
                      <code className="text-sm font-mono text-blue-600">{webhook.event}</code>
                      <Badge variant="outline" className="text-xs">{webhook.app}</Badge>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">{webhook.timestamp}</p>
                  </div>
                  {getStatusBadge(webhook.status)}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
