
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const session = await getServerSession();
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const projects = await prisma.project.findMany({
      include: {
        createdBy: {
          select: { id: true, name: true, email: true, department: true }
        },
        assignments: {
          include: {
            user: {
              select: { id: true, name: true, email: true, department: true }
            }
          }
        },
        tasks: {
          include: {
            task: {
              include: {
                department: true
              }
            }
          }
        },
        _count: {
          select: {
            tasks: true,
            assignments: true,
            timesheets: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json(projects);
  } catch (error) {
    console.error('Error fetching projects:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession();
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email }
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const body = await request.json();
    const {
      name,
      description,
      clientName,
      clientEmail,
      clientPhone,
      clientAddress,
      projectType,
      priority,
      quotedValue,
      marginPercent,
      startDate,
      endDate
    } = body;

    // Generate project number
    const projectCount = await prisma.project.count();
    const projectNumber = `SFG-${new Date().getFullYear()}-${String(projectCount + 1).padStart(4, '0')}`;

    // Calculate financial values
    const marginAmount = (quotedValue * marginPercent) / 100;
    const vatAmount = (quotedValue * 20) / 100; // 20% VAT
    const totalValue = quotedValue + vatAmount;

    const project = await prisma.project.create({
      data: {
        projectNumber,
        name,
        description,
        clientName,
        clientEmail,
        clientPhone,
        clientAddress,
        projectType,
        priority,
        quotedValue,
        marginPercent,
        vatAmount,
        totalValue,
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        createdById: user.id,
      },
      include: {
        createdBy: {
          select: { id: true, name: true, email: true, department: true }
        }
      }
    });

    // Create workflow steps
    const workflowSteps = [
      'Initial Enquiry & LOI',
      'Quotation & Proposal', 
      'Deposit Invoice & Payment',
      'Purchase Order (PO) Receipt',
      'Project Kick-Off & Planning',
      'Materials Procurement',
      'RAMS Preparation',
      'Site Survey',
      'Drawings & Design Approval',
      'Fabrication',
      'Powder Coating',
      'Packing & Delivery',
      'Site Mobilisation',
      'Frame Installation',
      'Glazing & Cappings',
      'Snagging & Quality Assurance',
      'O&M Manuals & Documentation',
      'Practical Completion & Handover',
      'Invoicing & Final Payment',
      'Retention Release'
    ];

    const workflowStepPromises = workflowSteps.map((stepName, index) =>
      prisma.workflowStep.create({
        data: {
          projectId: project.id,
          stepNumber: index + 1,
          stepName,
          status: index === 0 ? 'IN_PROGRESS' : 'PENDING',
        }
      })
    );

    await Promise.all(workflowStepPromises);

    return NextResponse.json(project, { status: 201 });
  } catch (error) {
    console.error('Error creating project:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
