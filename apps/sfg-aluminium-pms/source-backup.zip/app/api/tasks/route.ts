
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const session = await getServerSession();
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const departmentId = searchParams.get('department');
    const category = searchParams.get('category');
    const active = searchParams.get('active');

    const where: any = {};
    
    if (departmentId && departmentId !== 'all') {
      where.departmentId = departmentId;
    }
    
    if (category && category !== 'all') {
      where.category = category;
    }
    
    if (active !== null) {
      where.isActive = active === 'true';
    }

    const tasks = await prisma.task.findMany({
      where,
      include: {
        department: true,
        _count: {
          select: {
            projectTasks: true
          }
        }
      },
      orderBy: [
        { department: { name: 'asc' } },
        { orderIndex: 'asc' },
        { name: 'asc' }
      ]
    });

    return NextResponse.json(tasks);
  } catch (error) {
    console.error('Error fetching tasks:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession();
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { name, description, departmentId, category, estimatedHours } = body;

    const task = await prisma.task.create({
      data: {
        name,
        description,
        departmentId,
        category: category || 'Standard',
        estimatedHours: parseFloat(estimatedHours) || 1.0,
        isActive: true,
        orderIndex: await getNextOrderIndex(departmentId),
      },
      include: {
        department: true
      }
    });

    return NextResponse.json(task, { status: 201 });
  } catch (error) {
    console.error('Error creating task:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

async function getNextOrderIndex(departmentId: string): Promise<number> {
  const lastTask = await prisma.task.findFirst({
    where: { departmentId },
    orderBy: { orderIndex: 'desc' }
  });
  
  return (lastTask?.orderIndex || 0) + 1;
}
