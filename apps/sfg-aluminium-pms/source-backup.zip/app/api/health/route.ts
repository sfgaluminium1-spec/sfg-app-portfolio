
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    // Check database connection
    const startTime = Date.now();
    await prisma.$queryRaw`SELECT 1`;
    const dbResponseTime = Date.now() - startTime;

    // Get basic system stats
    const [projectCount, userCount, taskCount] = await Promise.all([
      prisma.project.count(),
      prisma.user.count(),
      prisma.task.count()
    ]);

    return NextResponse.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      app: {
        name: 'SFG Aluminium PMS',
        version: '1.0.0',
        environment: process.env.NODE_ENV || 'development'
      },
      dependencies: [
        {
          name: 'PostgreSQL',
          status: 'healthy',
          responseTime: dbResponseTime,
          critical: true
        },
        {
          name: 'NextAuth',
          status: 'healthy',
          critical: true
        },
        {
          name: 'Prisma ORM',
          status: 'healthy',
          critical: true
        }
      ],
      metrics: {
        projects: projectCount,
        users: userCount,
        tasks: taskCount,
        uptime: process.uptime(),
        memory: process.memoryUsage()
      }
    });
  } catch (error) {
    console.error('Health check failed:', error);
    return NextResponse.json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error',
      dependencies: [
        {
          name: 'PostgreSQL',
          status: 'unhealthy',
          critical: true
        }
      ]
    }, { status: 503 });
  }
}
