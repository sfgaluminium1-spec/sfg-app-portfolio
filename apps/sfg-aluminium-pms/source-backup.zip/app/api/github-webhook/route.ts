
import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    // Get request body
    const body = await request.json();
    
    // Verify webhook signature for security
    const signature = request.headers.get('x-hub-signature-256');
    const payload = JSON.stringify(body);
    const secret = process.env.GITHUB_WEBHOOK_SECRET || 'TEMP_SECRET_CHANGE_ME';

    // Verify signature if present
    if (signature) {
      const hmac = crypto.createHmac('sha256', secret);
      const digest = 'sha256=' + hmac.update(payload).digest('hex');

      if (signature !== digest) {
        console.error('Invalid webhook signature');
        return NextResponse.json({ error: 'Invalid signature' }, { status: 401 });
      }
    }

    // Handle push event (new instructions)
    const eventType = request.headers.get('x-github-event');
    
    if (eventType === 'push') {
      const APP_NAME = process.env.APP_NAME || 'sfg-aluminium-pms';
      const commits = body.commits || [];
      
      for (const commit of commits) {
        const files = [
          ...(commit.added || []),
          ...(commit.modified || [])
        ];
        
        // Check if our instruction file was updated
        const ourInstruction = `instructions/satellites/${APP_NAME}.md`;
        
        if (files.includes(ourInstruction)) {
          console.log(`🔔 New instruction detected in commit ${commit.id}`);
          console.log('Instruction URL:', commit.url);
          console.log('Commit message:', commit.message);
          
          // TODO: Implement instruction processing
          // 1. Fetch the instruction file from GitHub
          // 2. Parse the instruction markdown
          // 3. Create notification for admin
          // 4. Potentially auto-apply simple instructions
          
          console.log('⚠️ Admin: New instruction available from GitHub!');
          console.log('📋 Review instructions at:', commit.url);
        }
      }
    }

    // Handle ping event (webhook test)
    if (eventType === 'ping') {
      console.log('✅ GitHub webhook ping received');
      return NextResponse.json({ 
        status: 'ok', 
        message: 'Webhook endpoint is active',
        app: 'SFG Aluminium PMS'
      });
    }

    return NextResponse.json({ 
      status: 'ok',
      event: eventType,
      processed: true
    });
    
  } catch (error) {
    console.error('Error processing webhook:', error);
    return NextResponse.json({ 
      error: 'Internal server error',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}

// Health check endpoint
export async function GET() {
  return NextResponse.json({ 
    status: 'healthy',
    app: 'SFG Aluminium PMS',
    webhook: 'active',
    timestamp: new Date().toISOString()
  });
}
