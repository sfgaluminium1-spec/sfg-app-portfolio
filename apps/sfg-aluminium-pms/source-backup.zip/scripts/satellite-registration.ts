
import { Octokit } from '@octokit/rest';
import { createAppAuth } from '@octokit/auth-app';
import * as fs from 'fs';
import * as path from 'path';
import archiver from 'archiver';

// GitHub App Configuration
const GITHUB_APP_ID = '1098933';
const GITHUB_INSTALLATION_ID = '57738892';
const GITHUB_OWNER = 'IAMNISHANTSHUKLA';
const GITHUB_REPO = 'sfg-satellite-apps';
const PRIVATE_KEY_PATH = '/home/ubuntu/Uploads/sfg-satellite-apps-fixed.pem';

// App Information
const APP_NAME = 'sfg-aluminium-pms';
const APP_CATEGORY = 'PROJECT_MANAGEMENT';
const APP_DESCRIPTION = 'SFG Aluminium Project Management System - Comprehensive ERP system with project tracking, financial management, cost control, resource allocation, and workflows';
const APP_VERSION = '1.0.0';
const PROJECT_PATH = '/home/ubuntu/sfg_aluminium_pms/app';

interface RegistrationResult {
  success: boolean;
  message: string;
  prUrl?: string;
  branchName?: string;
  errors?: string[];
}

async function createSourceCodeArchive(): Promise<string> {
  return new Promise((resolve, reject) => {
    const archivePath = path.join(PROJECT_PATH, 'source-backup.zip');
    const output = fs.createWriteStream(archivePath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', () => {
      console.log(`✓ Source code archived: ${archive.pointer()} bytes`);
      resolve(archivePath);
    });

    archive.on('error', (err) => reject(err));
    archive.pipe(output);

    // Add all source files except node_modules, .next, etc.
    const excludePatterns = [
      'node_modules/**',
      '.next/**',
      '.git/**',
      'dist/**',
      'build/**',
      'coverage/**',
      '.yarn/**',
      'yarn.lock',
      'source-backup.zip',
      '*.log',
      '.env*',
      'tsconfig.tsbuildinfo'
    ];
    
    archive.glob('**/*', {
      cwd: PROJECT_PATH,
      ignore: excludePatterns,
      dot: true
    });

    archive.finalize();
  });
}

async function generateBusinessLogic(): Promise<object> {
  return {
    appId: APP_NAME,
    version: APP_VERSION,
    category: APP_CATEGORY,
    description: APP_DESCRIPTION,
    capabilities: [
      'project_management',
      'task_tracking',
      'financial_management',
      'cost_control',
      'resource_allocation',
      'document_management',
      'workflow_automation',
      'reporting_analytics',
      'multi_department_support'
    ],
    modules: [
      {
        id: 'dashboard',
        name: 'Dashboard',
        description: 'Centralized overview with KPIs and metrics',
        routes: ['/dashboard']
      },
      {
        id: 'projects',
        name: 'Project Management',
        description: 'Project creation, tracking, and management',
        routes: ['/projects']
      },
      {
        id: 'tasks',
        name: 'Task Management',
        description: 'Task assignment, tracking, and collaboration',
        routes: ['/tasks']
      },
      {
        id: 'financial',
        name: 'Financial Management',
        description: 'Budget tracking, expense management, and financial analytics',
        routes: ['/financial']
      },
      {
        id: 'cost_control',
        name: 'Cost Control',
        description: 'Cost estimation, tracking, and variance analysis',
        routes: ['/cost-control']
      },
      {
        id: 'resources',
        name: 'Resource Management',
        description: 'Equipment, material, and human resource allocation',
        routes: ['/resources']
      },
      {
        id: 'scheduling',
        name: 'Scheduling',
        description: 'Timeline planning and resource scheduling',
        routes: ['/scheduling']
      },
      {
        id: 'documents',
        name: 'Document Lifecycle',
        description: 'Document management and version control',
        routes: ['/documents-lifecycle']
      },
      {
        id: 'workflows',
        name: 'Workflow Management',
        description: 'Automated workflow creation and management',
        routes: ['/workflows']
      },
      {
        id: 'reports',
        name: 'Reports & Analytics',
        description: 'Comprehensive reporting and data visualization',
        routes: ['/reports']
      },
      {
        id: 'staff',
        name: 'Staff Management',
        description: 'Employee management and role assignments',
        routes: ['/staff']
      },
      {
        id: 'customers',
        name: 'Customer Management',
        description: 'Client relationship and project association',
        routes: ['/customers']
      }
    ],
    database: {
      type: 'PostgreSQL',
      orm: 'Prisma',
      models: [
        'User',
        'Department',
        'Project',
        'Task',
        'Customer',
        'Staff',
        'Resource',
        'Document',
        'Workflow',
        'FinancialRecord'
      ]
    },
    authentication: {
      provider: 'NextAuth',
      strategies: ['credentials'],
      roleBasedAccess: true
    },
    integrations: [
      {
        type: 'github',
        purpose: 'Version control and satellite app management'
      }
    ],
    deployment: {
      platform: 'abacusai.app',
      hostname: 'sfg-project-plus.abacusai.app',
      status: 'production'
    },
    technicalStack: {
      framework: 'Next.js 14',
      language: 'TypeScript',
      uiLibrary: 'React + Tailwind CSS + shadcn/ui',
      stateManagement: 'React Hooks + Context API',
      database: 'PostgreSQL with Prisma ORM',
      authentication: 'NextAuth.js',
      deployment: 'Abacus.AI Platform'
    }
  };
}

async function generateAppRegistration(): Promise<object> {
  return {
    registrationId: `${APP_NAME}-${Date.now()}`,
    timestamp: new Date().toISOString(),
    appMetadata: {
      name: APP_NAME,
      displayName: 'SFG Aluminium PMS',
      version: APP_VERSION,
      category: APP_CATEGORY,
      description: APP_DESCRIPTION,
      author: 'SFG Aluminium',
      license: 'Proprietary',
      homepage: 'https://sfg-project-plus.abacusai.app',
      repository: {
        type: 'git',
        url: 'https://github.com/IAMNISHANTSHUKLA/sfg-satellite-apps'
      }
    },
    registrationMethod: 'automated',
    githubApp: {
      appId: GITHUB_APP_ID,
      installationId: GITHUB_INSTALLATION_ID,
      owner: GITHUB_OWNER,
      repository: GITHUB_REPO
    },
    files: {
      sourceCodeBackup: 'source-backup.zip',
      businessLogic: 'business-logic.json',
      registrationManifest: 'app-registration.json'
    },
    status: 'pending_review',
    registeredBy: 'DeepAgent Autonomous System',
    notes: 'Fully automated registration process with comprehensive documentation'
  };
}

async function registerSatelliteApp(): Promise<RegistrationResult> {
  const errors: string[] = [];
  
  try {
    console.log('🚀 Starting SFG Aluminium PMS Satellite App Registration...\n');

    // Step 1: Verify private key
    console.log('Step 1/8: Verifying GitHub App credentials...');
    if (!fs.existsSync(PRIVATE_KEY_PATH)) {
      throw new Error(`Private key not found at: ${PRIVATE_KEY_PATH}`);
    }
    const privateKey = fs.readFileSync(PRIVATE_KEY_PATH, 'utf8');
    console.log('✓ Private key loaded\n');

    // Step 2: Authenticate with GitHub App
    console.log('Step 2/8: Authenticating with GitHub...');
    const octokit = new Octokit({
      authStrategy: createAppAuth,
      auth: {
        appId: GITHUB_APP_ID,
        privateKey: privateKey,
        installationId: GITHUB_INSTALLATION_ID,
      },
    });
    console.log('✓ GitHub authentication successful\n');

    // Step 3: Create source code archive
    console.log('Step 3/8: Creating source code backup archive...');
    const archivePath = await createSourceCodeArchive();
    console.log('✓ Source code backup created\n');

    // Step 4: Generate business logic document
    console.log('Step 4/8: Generating business logic documentation...');
    const businessLogic = await generateBusinessLogic();
    const businessLogicPath = path.join(PROJECT_PATH, 'business-logic.json');
    fs.writeFileSync(businessLogicPath, JSON.stringify(businessLogic, null, 2));
    console.log('✓ Business logic document generated\n');

    // Step 5: Generate app registration manifest
    console.log('Step 5/8: Generating registration manifest...');
    const appRegistration = await generateAppRegistration();
    const registrationPath = path.join(PROJECT_PATH, 'app-registration.json');
    fs.writeFileSync(registrationPath, JSON.stringify(appRegistration, null, 2));
    console.log('✓ Registration manifest generated\n');

    // Step 6: Create branch
    console.log('Step 6/8: Creating registration branch...');
    const branchName = `satellite-app/register-${APP_NAME}-${Date.now()}`;
    
    // Get default branch reference
    const { data: ref } = await octokit.rest.git.getRef({
      owner: GITHUB_OWNER,
      repo: GITHUB_REPO,
      ref: 'heads/main',
    });
    
    // Create new branch
    await octokit.rest.git.createRef({
      owner: GITHUB_OWNER,
      repo: GITHUB_REPO,
      ref: `refs/heads/${branchName}`,
      sha: ref.object.sha,
    });
    console.log(`✓ Branch created: ${branchName}\n`);

    // Step 7: Upload registration files
    console.log('Step 7/8: Uploading registration files...');
    
    const files = [
      {
        path: `apps/${APP_NAME}/business-logic.json`,
        content: fs.readFileSync(businessLogicPath, 'utf8'),
        message: 'Add business logic documentation'
      },
      {
        path: `apps/${APP_NAME}/app-registration.json`,
        content: fs.readFileSync(registrationPath, 'utf8'),
        message: 'Add registration manifest'
      },
      {
        path: `apps/${APP_NAME}/source-backup.zip`,
        content: fs.readFileSync(archivePath).toString('base64'),
        message: 'Add source code backup',
        encoding: 'base64'
      },
      {
        path: `apps/${APP_NAME}/README.md`,
        content: `# SFG Aluminium PMS - Satellite App Registration

## App Information
- **Name:** SFG Aluminium PMS
- **Version:** ${APP_VERSION}
- **Category:** ${APP_CATEGORY}
- **Deployment URL:** https://sfg-project-plus.abacusai.app

## Description
${APP_DESCRIPTION}

## Registration Details
- **Registration Date:** ${new Date().toISOString()}
- **Registration Method:** Automated via DeepAgent
- **Status:** Pending Review

## Files Included
- \`business-logic.json\` - Complete business logic and technical documentation
- \`app-registration.json\` - Registration manifest with metadata
- \`source-backup.zip\` - Full source code backup
- \`README.md\` - This file

## Next Steps
1. Review registration files
2. Validate app compliance with satellite app guidelines
3. Approve or request modifications
4. Merge to main branch for official registration

---
*Registered autonomously by DeepAgent on ${new Date().toLocaleDateString()}*
`,
        message: 'Add README documentation'
      }
    ];

    for (const file of files) {
      try {
        await octokit.rest.repos.createOrUpdateFileContents({
          owner: GITHUB_OWNER,
          repo: GITHUB_REPO,
          path: file.path,
          message: file.message,
          content: file.encoding === 'base64' ? file.content : Buffer.from(file.content).toString('base64'),
          branch: branchName,
        });
        console.log(`  ✓ Uploaded: ${file.path}`);
      } catch (err: any) {
        console.error(`  ✗ Failed to upload ${file.path}: ${err.message}`);
        errors.push(`Failed to upload ${file.path}: ${err.message}`);
      }
    }
    console.log('✓ All files uploaded\n');

    // Step 8: Create Pull Request
    console.log('Step 8/8: Creating pull request...');
    const { data: pr } = await octokit.rest.pulls.create({
      owner: GITHUB_OWNER,
      repo: GITHUB_REPO,
      title: `🛰️ Register Satellite App: ${APP_NAME}`,
      head: branchName,
      base: 'main',
      body: `## Satellite App Registration: SFG Aluminium PMS

### 📋 App Details
- **Name:** SFG Aluminium PMS
- **Version:** ${APP_VERSION}
- **Category:** ${APP_CATEGORY}
- **Deployment:** [sfg-project-plus.abacusai.app](https://sfg-project-plus.abacusai.app)

### 📝 Description
${APP_DESCRIPTION}

### 🎯 Capabilities
- Project Management & Tracking
- Task Assignment & Collaboration
- Financial Management & Analytics
- Cost Control & Estimation
- Resource Allocation
- Document Lifecycle Management
- Workflow Automation
- Comprehensive Reporting
- Multi-Department Support

### 📦 Included Files
- ✅ \`business-logic.json\` - Complete technical documentation
- ✅ \`app-registration.json\` - Registration manifest
- ✅ \`source-backup.zip\` - Full source code backup
- ✅ \`README.md\` - Documentation

### 🔧 Technical Stack
- **Framework:** Next.js 14 with TypeScript
- **UI:** React + Tailwind CSS + shadcn/ui
- **Database:** PostgreSQL with Prisma ORM
- **Authentication:** NextAuth.js
- **Deployment:** Abacus.AI Platform

### ✅ Registration Checklist
- [x] Source code backup created
- [x] Business logic documented
- [x] Registration manifest generated
- [x] All files uploaded to repository
- [x] README documentation included

### 🤖 Registration Method
**Automated Registration** via DeepAgent Autonomous System

### 📅 Registration Date
${new Date().toISOString()}

---

**Ready for Review** - Please review and merge to complete the registration process.
`,
    });

    console.log(`✓ Pull request created: ${pr.html_url}\n`);

    // Clean up temporary files
    fs.unlinkSync(archivePath);
    fs.unlinkSync(businessLogicPath);
    fs.unlinkSync(registrationPath);

    return {
      success: true,
      message: 'Satellite app registration completed successfully!',
      prUrl: pr.html_url,
      branchName: branchName,
      errors: errors.length > 0 ? errors : undefined
    };

  } catch (error: any) {
    console.error('\n❌ Registration failed:', error.message);
    return {
      success: false,
      message: `Registration failed: ${error.message}`,
      errors: [...errors, error.message]
    };
  }
}

// Execute registration
registerSatelliteApp()
  .then((result) => {
    console.log('\n' + '='.repeat(70));
    if (result.success) {
      console.log('✅ SUCCESS - SATELLITE APP REGISTRATION COMPLETED');
      console.log('='.repeat(70));
      console.log(`\n🔗 Pull Request: ${result.prUrl}`);
      console.log(`🌿 Branch: ${result.branchName}`);
      console.log('\n📋 Next Steps:');
      console.log('   1. Review the pull request at the URL above');
      console.log('   2. Validate all registration files');
      console.log('   3. Merge the PR to complete registration');
      console.log('\n✨ Registration process completed autonomously!');
      
      if (result.errors && result.errors.length > 0) {
        console.log('\n⚠️  Warnings during registration:');
        result.errors.forEach(err => console.log(`   - ${err}`));
      }
    } else {
      console.log('❌ FAILED - SATELLITE APP REGISTRATION');
      console.log('='.repeat(70));
      console.log(`\n${result.message}`);
      if (result.errors && result.errors.length > 0) {
        console.log('\nErrors:');
        result.errors.forEach(err => console.log(`   - ${err}`));
      }
      process.exit(1);
    }
    console.log('\n' + '='.repeat(70) + '\n');
  })
  .catch((error) => {
    console.error('\n💥 FATAL ERROR:', error);
    process.exit(1);
  });
