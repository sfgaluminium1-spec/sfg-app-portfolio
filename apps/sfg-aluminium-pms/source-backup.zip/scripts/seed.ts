
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting SFG Aluminium PMS database seeding...');

  // Create system settings
  console.log('⚙️ Creating system settings...');
  const settings = [
    { key: 'hourly_wage', value: '18.0', type: 'float' },
    { key: 'charge_out_rate', value: '36.0', type: 'float' },
    { key: 'overtime_rate', value: '27.0', type: 'float' },
    { key: 'standard_hours_per_day', value: '8.5', type: 'float' },
    { key: 'lunch_break_minutes', value: '30', type: 'integer' },
    { key: 'morning_break_minutes', value: '10', type: 'integer' },
    { key: 'afternoon_break_minutes', value: '15', type: 'integer' },
    { key: 'monthly_overhead', value: '50000', type: 'float' },
    { key: 'annual_overhead', value: '2142857', type: 'float' },
    { key: 'daily_overhead', value: '2500', type: 'float' },
    { key: 'vat_rate', value: '20', type: 'float' },
    { key: 'weekend_multiplier', value: '1.5', type: 'float' },
    { key: 'supply_install_margin', value: '45', type: 'float' },
    { key: 'supply_only_margin', value: '30', type: 'float' },
    { key: 'services_margin', value: '30', type: 'float' },
    { key: 'maintenance_margin', value: '10', type: 'float' },
    { key: 'repair_margin', value: '10', type: 'float' },
    { key: 'simple_sale_margin', value: '5', type: 'float' },
    { key: 'corporate_margin', value: '55', type: 'float' },
    { key: 'corporate_admin', value: '20', type: 'float' },
    { key: 'quotation_drop_min', value: '40', type: 'float' },
    { key: 'quotation_drop_max', value: '45', type: 'float' },
    { key: 'po_drop_threshold_low', value: '5', type: 'float' },
    { key: 'po_drop_threshold_high', value: '28', type: 'float' },
  ];

  for (const setting of settings) {
    await prisma.settings.upsert({
      where: { key: setting.key },
      update: { value: setting.value, type: setting.type },
      create: setting,
    });
  }

  // Create admin user
  console.log('👤 Creating admin user...');
  const hashedPassword = await bcrypt.hash('johndoe123', 12);
  const adminUser = await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: {},
    create: {
      email: 'john@doe.com',
      name: 'John Doe',
      password: hashedPassword,
      role: 'ADMIN',
      department: 'Office',
      hourlyRate: 18.0,
      chargeOutRate: 36.0,
      overtimeRate: 27.0,
      isActive: true,
    },
  });

  // Create departments with colors
  console.log('🏢 Creating departments...');
  const departments = [
    { name: 'Office', description: 'Administrative and management tasks', color: '#3B82F6' },
    { name: 'Factory', description: 'Fabrication and manufacturing operations', color: '#EF4444' },
    { name: 'Installation', description: 'On-site installation and construction', color: '#10B981' },
    { name: 'Maintenance', description: 'Maintenance and repair operations', color: '#F59E0B' },
    { name: 'Warehouse', description: 'Storage and logistics operations', color: '#8B5CF6' },
  ];

  const createdDepartments: { [key: string]: any } = {};
  for (const dept of departments) {
    const department = await prisma.department.upsert({
      where: { name: dept.name },
      update: dept,
      create: dept,
    });
    createdDepartments[dept.name] = department;
  }

  // Create all tasks by department
  console.log('📋 Creating tasks...');

  // Office Tasks (28 tasks)
  const officeTasks = [
    'Receive/log customer enquiry',
    'Issue Letter of Intent (LOI)',
    'Prepare detailed quotation (materials, labor, overheads, margin)',
    'Submit proposal to client',
    'Generate/send deposit invoice',
    'Track payment status',
    'Receive/log client PO',
    'Cross-check PO with proposal',
    'Schedule internal kick-off meeting',
    'Assign project team/responsibilities',
    'Develop project plan/Gantt chart',
    'Identify milestones/dependencies',
    'Communicate plan to stakeholders',
    'Compile operating/maintenance manuals',
    'Deliver manuals to client',
    'Issue interim/final invoice',
    'Track payments/update records',
    'Monitor defect liability period/release retention',
    'Handle staff issues/terminations/sick leave',
    'Provide regular training on industry trends/safety standards',
    'Log training/certification records',
    'Contact employees off sick with sensitive messages',
    'Cleaning of office areas',
    'Sanitation/cleaning of establishment (office part)',
    'Distributing mail/delivering',
    'Operating office machines (printers/copiers/scanners/coin counting/wrapping/mail room)',
    'Service/repair of office machines',
    'Support service activities for businesses (administrative)',
  ];

  // Factory/Fabrication Tasks (36 tasks)
  const factoryTasks = [
    'Receive/check materials',
    'Cut/machine/assemble profiles',
    'Inspect dimensional accuracy/finish',
    'Record batch numbers/QC results',
    'Stage components for coating/delivery',
    'Prepare profiles for coating',
    'Apply powder coating to specification',
    'Cure/inspect finish',
    'Record coating batch/test results',
    'Pack components for transport',
    'Arrange delivery',
    'Confirm schedule with site team',
    'Track/log delivery',
    'Material prep & CNC',
    'Assembly & fabrication',
    'QC, packing & loading',
    'Cleaning factory/toilets',
    'Packing stock',
    'Unloading vehicles',
    'Forklift driving',
    'Taping profiles after coating',
    'Sanding profiles in coating',
    'Powder coating by spray on gold aluminum/steel profiles',
    'Operating factory machines (extrusion, cutting, bending)',
    'Storing/distributing/accounting for stores of materials',
    'Abrasive blasting',
    'Welding, cutting, torch burning',
    'Lubricate bearing, pins, pivot points',
    'Grinding and polishing compounds',
    'Repairs damage to metal surfaces using arc or acetylene welding',
    'Abrasives, solid wheels, stones',
    'Abrasives, tumbling wheel',
    'Mix cleaning solution per manufacturer recommendation',
    'Use spray, not stream, of water',
    'Oxygen-fuel gas welding and cutting',
    'Personal protection for blasting operations',
  ];

  // Installation Tasks (20 tasks)
  const installationTasks = [
    'Mobilise equipment (scissor lift, tools, PPE)',
    'Conduct site induction/safety briefing',
    'Set up welfare facilities',
    'Set out/fix curtain wall frames',
    'Check plumb, level, alignment',
    'Secure fixings/anchors',
    'Install glass units per sequence',
    'Fit cappings/apply sealants',
    'Inspect for fit/finish',
    'Conduct snagging inspection',
    'List/rectify defects',
    'Final QA check/sign-off',
    'Prepare snagging report',
    'Conduct final walkdown',
    'Obtain practical completion sign-off',
    'Site condition survey & protection of existing improvements',
    'Certified survey on completion of foundation walls',
    'Site setup/unloading',
    'Fixing/sealing/glazing',
    'Finishing/silicone/clean-up',
  ];

  // Maintenance/Repairs Tasks (26 tasks)
  const maintenanceTasks = [
    'Planned/preventative maintenance (lubrication, adjustment, safety checks, cleaning)',
    'Emergency/scheduled repairs (breakages, vandalism, hardware replacement, upgrades)',
    'Remedial works (failed units)',
    'Monitor/troubleshoot/repair equipment',
    'Cleaning of machines/equipment',
    'Sanitation/cleaning of establishment (warehouse/factory)',
    'Preventive maintenance: inspections, lubrication, belt adjustments, cleaning, component replacements',
    'Scheduled maintenance activities: lubrication, cleaning, visual inspections, component replacements',
    'Preventive maintenance for aluminum melting furnaces',
    'Activities such as lubrication, cleaning, inspection of components, replacement of worn parts',
    'Preventive maintenance: periodic inspections, lubrication, analysis of wear and tear, cleaning, calibration',
    'Preventive maintenance program for material handling equipment',
    'Preventive maintenance: inspections, lubrication, part replacements, repairs',
    'Maintenance management: preventive includes tasks like inspections, lubrication, cleaning, calibration',
    'Impact of maintenance on machine reliability',
    'Preventive maintenance: improve motor performance, lubrication, regular health check',
    'Facilities preventive maintenance program: inspections, lubrication, repairs',
    'Ultimate preventive maintenance checklists for CMMS',
    'Preventive maintenance: inspections, lubrication, part replacements, extend lifespan',
    'Guide to preventive maintenance checklist and repair program',
    'Managing equipment maintenance and calibration',
    'Maintenance fundamentals: basic preventive tasks (lubrication, machine adjustments)',
    'Facilities Preventive Maintenance Program: validating equipment presence/functional monthly, certified professionals for repairs',
    'GSA PUBLIC BUILDING SERVICE PREVENTIVE MAINTENANCE GUIDE CARDS: Lubricate bearing, pins, pivot points',
    'Operations & Maintenance Manual: Supplementary to specific operating, maintenance, repair procedures',
    'RCM Guide: NASA RCM Logic Tree for equipment maintenance',
  ];

  // Warehouse/Other Tasks (13 tasks)
  const warehouseTasks = [
    'Packing away of stock',
    'Unloading vehicles outside',
    'Forklift truck driving',
    'Storing/distributing/accounting for stores of materials',
    'Warehouse duties: receiving, storing, inventory control, picking, packing, shipping, unloading',
    'Cleaning warehouse',
    'Operating/maintenance of powered industrial trucks (forklifts)',
    'Blasting associated with blaster-in-charge/explosive site safety plan',
    'Cleaning of the works',
    'Sanitation/cleaning of establishment',
    'Service/repair of office machines/printers/copiers/scanners/coin counting/wrapping/mail room',
    'Distributing mail/delivering',
    'Support service activities for businesses',
  ];

  // Additional tasks from research to reach 142 total
  const additionalTasks = [
    // BIM and Design tasks
    'BIM model creation for curtain wall systems with clash detection',
    'Shop drawing coordination with structural, MEP, and waterproofing trades',
    'Mock-up design and testing protocol development',
    'Structural silicone and dynamic load analysis',
    'Digital bill-of-materials generation with market rate integration',
    'Automated cutting optimization using reverse-forward algorithms',
    'Real-time quality monitoring with IoT sensor integration',
    'Advanced surface treatment process control (anodizing parameters)',
    'Panel hoisting and rigging procedure development',
    'Site logistics coordination (laydown areas, crane access)',
    'Weather protection protocol for sensitive operations',
    'Final air and water infiltration testing procedures',
    'EN 1090 compliance documentation system',
    'Welder qualification tracking and renewal management',
    'Non-destructive testing (NDT) procedure implementation',
    'Factory Production Control (FPC) system maintenance',
    'ERP system integration with shop floor data collection',
    'Digital work instruction deployment with QR code access',
    'Remote diagnostics and OEM support integration',
  ];

  // Create tasks for each department
  const tasksByDept = [
    { dept: 'Office', tasks: officeTasks },
    { dept: 'Factory', tasks: factoryTasks },
    { dept: 'Installation', tasks: installationTasks },
    { dept: 'Maintenance', tasks: maintenanceTasks },
    { dept: 'Warehouse', tasks: warehouseTasks },
  ];

  // Add additional tasks to Office department to reach target count
  tasksByDept[0].tasks.push(...additionalTasks);

  let taskCount = 0;
  for (const { dept, tasks } of tasksByDept) {
    for (let i = 0; i < tasks.length; i++) {
      await prisma.task.create({
        data: {
          name: tasks[i],
          departmentId: createdDepartments[dept].id,
          category: 'Standard',
          estimatedHours: Math.random() * 4 + 1, // Random between 1-5 hours
          orderIndex: i + 1,
          isActive: true,
        },
      });
      taskCount++;
    }
  }

  console.log(`✅ Created ${taskCount} tasks across all departments`);

  console.log('🌱 Database seeding completed successfully!');
  console.log('📊 Summary:');
  console.log(`   - Departments: ${departments.length}`);
  console.log(`   - Tasks: ${taskCount}`);
  console.log(`   - Settings: ${settings.length}`);
  console.log(`   - Admin User: john@doe.com / johndoe123`);
}

main()
  .catch((e) => {
    console.error('❌ Error during seeding:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
